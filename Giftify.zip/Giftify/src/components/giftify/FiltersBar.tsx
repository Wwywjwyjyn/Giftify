"use client";

import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, RotateCcw } from "lucide-react";

export type Filters = {
  q: string;
  collection: string;
  currency: string;
  status: string;
  sort: string;
  min: string;
  max: string;
};

export const DEFAULT_FILTERS: Filters = {
  q: "",
  collection: "",
  currency: "",
  status: "ACTIVE",
  sort: "newest",
  min: "",
  max: "",
};

export default function FiltersBar({
  value,
  collections,
  onChange,
  onReset,
}: {
  value: Filters;
  collections: { slug: string; name: string; emoji: string | null; activeCount: number }[];
  onChange: (patch: Partial<Filters>) => void;
  onReset: () => void;
}) {
  const selectCls =
    "h-9 min-w-0 rounded-lg border-border bg-secondary text-[12px] text-foreground";
  return (
    <div className="flex flex-col gap-2.5 rounded-xl border border-border bg-card/50 p-3">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative min-w-44 flex-1">
          <Search className="absolute right-2.5 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={value.q}
            onChange={(e) => onChange({ q: e.target.value })}
            placeholder="جست‌وجوی هدیه یا مجموعه…"
            className="h-9 rounded-lg border-border bg-secondary pr-8 text-[12px]"
            aria-label="جست‌وجو"
          />
        </div>
        <Select value={value.collection || "all"} onValueChange={(v) => onChange({ collection: v === "all" ? "" : v })}>
          <SelectTrigger className={`${selectCls} w-40`} aria-label="مجموعه">
            <SelectValue placeholder="مجموعه" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه مجموعه‌ها</SelectItem>
            {collections.map((c) => (
              <SelectItem key={c.slug} value={c.slug}>
                {c.emoji ? `${c.emoji} ` : ""}
                {c.name} ({c.activeCount})
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={value.currency || "all"} onValueChange={(v) => onChange({ currency: v === "all" ? "" : v })}>
          <SelectTrigger className={`${selectCls} w-28`} aria-label="ارز">
            <SelectValue placeholder="ارز" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه ارزها</SelectItem>
            <SelectItem value="TON">TON</SelectItem>
            <SelectItem value="STARS">⭐ استارز</SelectItem>
          </SelectContent>
        </Select>
        <Select value={value.status || "ACTIVE"} onValueChange={(v) => onChange({ status: v })}>
          <SelectTrigger className={`${selectCls} w-28`} aria-label="وضعیت">
            <SelectValue placeholder="وضعیت" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ACTIVE">در فروش</SelectItem>
            <SelectItem value="SOLD">فروخته‌شده</SelectItem>
            <SelectItem value="all">همه</SelectItem>
          </SelectContent>
        </Select>
        <Select value={value.sort || "newest"} onValueChange={(v) => onChange({ sort: v })}>
          <SelectTrigger className={`${selectCls} w-32`} aria-label="مرتب‌سازی">
            <SelectValue placeholder="مرتب‌سازی" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="newest">جدیدترین</SelectItem>
            <SelectItem value="price_asc">ارزان‌ترین</SelectItem>
            <SelectItem value="price_desc">گران‌ترین</SelectItem>
            <SelectItem value="serial_asc">کم‌ترین شماره</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-[11px] text-muted-foreground">محدوده قیمت:</span>
        <Input
          value={value.min}
          onChange={(e) => onChange({ min: e.target.value })}
          type="number"
          inputMode="decimal"
          placeholder="از"
          className="tnum h-8 w-24 rounded-lg border-border bg-secondary text-[12px]"
          aria-label="حداقل قیمت"
        />
        <Input
          value={value.max}
          onChange={(e) => onChange({ max: e.target.value })}
          type="number"
          inputMode="decimal"
          placeholder="تا"
          className="tnum h-8 w-24 rounded-lg border-border bg-secondary text-[12px]"
          aria-label="حداکثر قیمت"
        />
        <Button variant="ghost" size="sm" onClick={onReset} className="h-8 gap-1 text-[12px] text-muted-foreground">
          <RotateCcw className="size-3" />
          حذف فیلترها
        </Button>
      </div>
    </div>
  );
}
