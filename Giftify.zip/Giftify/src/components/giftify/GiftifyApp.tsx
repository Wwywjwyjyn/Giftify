"use client";

import { useEffect } from "react";
import { useApp, useHashRouter } from "@/lib/store";
import TonProvider from "@/components/giftify/TonProvider";
import TelegramProvider from "@/components/giftify/TelegramProvider";
import Header from "@/components/giftify/Header";
import HomeView from "@/components/giftify/views/Home";
import MarketView from "@/components/giftify/views/Market";
import GiftDetailView from "@/components/giftify/views/GiftDetail";
import SellView from "@/components/giftify/views/Sell";
import ProfileView from "@/components/giftify/views/Profile";
import AdminView from "@/components/giftify/views/Admin";
import AuthView from "@/components/giftify/views/Auth";
import { faDigits } from "@/lib/format";

function Footer() {
  const settings = useApp((s) => s.settings);
  return (
    <footer className="mt-auto border-t border-border/70 bg-background">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-1.5 px-4 py-5 safe-bottom text-center">
        <span className="font-nastaliq text-xl text-foreground/90">{settings?.site_name || "گیفتیفای"}</span>
        <p className="text-[10px] text-muted-foreground">
          بازار هدیه‌های تلگرام — پرداخت مستقیم TON، کارمزد شفاف {faDigits(settings?.fee_sale_percent ?? 5)}٪
        </p>
      </div>
    </footer>
  );
}

function View() {
  const route = useApp((s) => s.route);
  const path = route.path;

  if (path === "" || path === "home") return <HomeView />;
  if (path === "market") return <MarketView />;
  if (path.startsWith("gift/")) {
    const id = path.split("/")[1];
    return id ? <GiftDetailView key={id} id={id} /> : <HomeView />;
  }
  if (path === "sell") return <SellView />;
  if (path === "profile") return <ProfileView />;
  if (path === "admin") return <AdminView />;
  if (path === "auth") return <AuthView />;

  return (
    <div className="mx-auto max-w-md px-4 py-20 text-center text-sm text-muted-foreground">
      صفحه پیدا نشد —{" "}
      <button onClick={() => window.location.hash = "#/"} className="text-petrol-bright hover:underline">
        بازگشت به خانه
      </button>
    </div>
  );
}

export default function GiftifyApp() {
  useHashRouter();
  const refreshMe = useApp((s) => s.refreshMe);
  const route = useApp((s) => s.route);

  useEffect(() => {
    refreshMe();
  }, [refreshMe]);

  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [route.path]);

  return (
    <TonProvider>
      <TelegramProvider />
      <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex-1">
          <View />
        </main>
        <Footer />
      </div>
    </TonProvider>
  );
}
