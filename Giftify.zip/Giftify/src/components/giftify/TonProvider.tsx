"use client";

import dynamic from "next/dynamic";

const TonInner = dynamic(() => import("./TonInner"), { ssr: false });

export default function TonProvider({ children }: { children: React.ReactNode }) {
  return <TonInner>{children}</TonInner>;
}
