"use client";

import { useState } from "react";
import { useTonConnectUI, useTonAddress } from "@tonconnect/ui-react";
import { useRouter } from "@/lib/nav";
import { useApp } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet";
import {
  Wallet,
  Menu,
  Plus,
  Shield,
  User,
  LogIn,
  LogOut,
  LayoutGrid,
  Activity,
} from "lucide-react";
import { faDigits } from "@/lib/format";

function shortAddr(a: string) {
  return `${a.slice(0, 4)}…${a.slice(-4)}`;
}

export default function Header() {
  const router = useRouter();
  const { path } = useApp((s) => s.route);
  const user = useApp((s) => s.user);
  const settings = useApp((s) => s.settings);
  const refreshMe = useApp((s) => s.refreshMe);
  const [tonConnectUI] = useTonConnectUI();
  const address = useTonAddress();
  const [menuOpen, setMenuOpen] = useState(false);

  const siteName = settings?.site_name || "گیفتیفای";

  const links = [
    { to: "market", label: "بازار", icon: LayoutGrid },
    { to: "sell", label: "ثبت آگهی", icon: Plus },
    ...(user?.role === "ADMIN" ? [{ to: "admin", label: "پنل مدیریت", icon: Shield }] : []),
  ];

  const isActive = (to: string) => path === to;

  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    await refreshMe();
    setMenuOpen(false);
    router.go("");
  };

  return (
    <header className="sticky top-0 z-40 safe-top">
      <div className="border-b border-border/80 bg-background/85 backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-6xl items-center gap-3 px-4">
          {/* Wordmark — minimal, Nastaliq, like Fragment's logo */}
          <button
            onClick={() => router.go("")}
            className="flex flex-col items-start leading-none transition-opacity hover:opacity-80"
            aria-label="صفحه اصلی"
          >
            <span className="font-nastaliq text-2xl text-foreground">{siteName}</span>
            <span className="text-[9px] font-semibold tracking-[0.35em] text-petrol-bright/80">
              GIFTIFY
            </span>
          </button>

          {/* Desktop nav */}
          <nav className="mr-4 hidden items-center gap-1 md:flex" aria-label="ناوبری اصلی">
            {links.map((l) => (
              <button
                key={l.to}
                onClick={() => router.go(l.to)}
                className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[13px] font-medium transition-colors ${
                  isActive(l.to)
                    ? "bg-accent text-accent-foreground"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <l.icon className="size-3.5" />
                {l.label}
              </button>
            ))}
          </nav>

          <div className="flex-1" />

          {/* Wallet */}
          {address ? (
            <Button
              variant="secondary"
              size="sm"
              onClick={() => tonConnectUI.openModal()}
              className="tnum gap-1.5 border-petrol/25 bg-petrol-ink/50 text-petrol-bright hover:bg-petrol-ink"
            >
              <Wallet className="size-3.5" />
              {shortAddr(address)}
            </Button>
          ) : (
            <Button size="sm" onClick={() => tonConnectUI.openModal()} className="gap-1.5">
              <Wallet className="size-3.5" />
              اتصال کیف پول
            </Button>
          )}

          {/* Auth */}
          {!user ? (
            <Button variant="outline" size="sm" onClick={() => router.go("auth")} className="gap-1.5">
              <LogIn className="size-3.5" />
              ورود
            </Button>
          ) : (
            <div className="hidden items-center gap-1 md:flex">
              <Button variant="ghost" size="sm" onClick={() => router.go("profile")} className="gap-1.5">
                <User className="size-3.5" />
                {user.username}
              </Button>
              <Button variant="ghost" size="icon" onClick={logout} aria-label="خروج" title="خروج">
                <LogOut className="size-4" />
              </Button>
            </div>
          )}

          {/* Mobile menu */}
          <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden" aria-label="منو">
                <Menu className="size-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72 border-border bg-card">
              <SheetTitle className="font-nastaliq text-2xl">{siteName}</SheetTitle>
              <div className="mt-4 flex flex-col gap-1">
                {[
                  { to: "", label: "خانه", icon: Activity },
                  ...links,
                  ...(user ? [{ to: "profile", label: `حساب: ${user.username}`, icon: User }] : [{ to: "auth", label: "ورود / ثبت‌نام", icon: LogIn }]),
                ].map((l) => (
                  <button
                    key={l.label}
                    onClick={() => {
                      router.go(l.to);
                      setMenuOpen(false);
                    }}
                    className="flex items-center gap-2 rounded-lg px-3 py-2.5 text-sm text-foreground/90 transition hover:bg-accent"
                  >
                    <l.icon className="size-4 text-petrol-bright" />
                    {l.label}
                  </button>
                ))}
                {user && (
                  <button
                    onClick={logout}
                    className="mt-2 flex items-center gap-2 rounded-lg px-3 py-2.5 text-sm text-danger transition hover:bg-destructive/10"
                  >
                    <LogOut className="size-4" />
                    خروج از حساب
                  </button>
                )}
              </div>
              <p className="mt-6 text-[11px] leading-5 text-muted-foreground">
                کارمزد فروش: {faDigits(settings?.fee_sale_percent ?? 5)}٪ — شفاف و قابل مشاهده در هر معامله.
              </p>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
