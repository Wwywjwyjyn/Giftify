"use client";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { PriceBadge, StatusBadge } from "@/components/giftify/bits";
import { timeAgoFa } from "@/lib/format";

export type ListingRow = {
  id: string;
  title: string;
  emoji: string | null;
  serialNumber: number | null;
  currency: string;
  price: number;
  status: string;
  createdAt: string;
  collection?: { name: string; emoji?: string | null } | null;
  seller?: { username: string } | null;
};

/** Fragment-style market table: dense rows, hover, price at the end. */
export default function GiftTable({
  listings,
  onOpen,
  showStatus = true,
}: {
  listings: ListingRow[];
  onOpen: (id: string) => void;
  showStatus?: boolean;
}) {
  return (
    <div className="overflow-x-auto rounded-xl border border-border bg-card/50">
      <Table>
        <TableHeader>
          <TableRow className="hover:bg-transparent">
            <TableHead className="text-right text-[11px] font-semibold text-muted-foreground">هدیه</TableHead>
            <TableHead className="hidden text-right text-[11px] font-semibold text-muted-foreground sm:table-cell">مجموعه</TableHead>
            <TableHead className="hidden text-right text-[11px] font-semibold text-muted-foreground md:table-cell">شماره</TableHead>
            <TableHead className="text-right text-[11px] font-semibold text-muted-foreground">فروشنده</TableHead>
            {showStatus && (
              <TableHead className="hidden text-right text-[11px] font-semibold text-muted-foreground sm:table-cell">وضعیت</TableHead>
            )}
            <TableHead className="text-left text-[11px] font-semibold text-muted-foreground">قیمت</TableHead>
            <TableHead className="hidden text-left text-[11px] font-semibold text-muted-foreground lg:table-cell">زمان</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {listings.map((l) => (
            <TableRow
              key={l.id}
              onClick={() => onOpen(l.id)}
              className="row-hover cursor-pointer border-border/60"
            >
              <TableCell className="max-w-52 py-3">
                <div className="flex items-center gap-2.5">
                  <span className="grid size-9 shrink-0 place-items-center rounded-lg border border-petrol/15 bg-petrol-ink/40 text-lg">
                    {l.emoji || "🎁"}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-[13px] font-semibold text-foreground">{l.title}</p>
                    <p className="text-[11px] text-muted-foreground lg:hidden">{l.collection?.name || "—"}</p>
                  </div>
                </div>
              </TableCell>
              <TableCell className="hidden text-[12px] text-muted-foreground sm:table-cell">
                {l.collection ? `${l.collection.emoji || ""} ${l.collection.name}`.trim() : "—"}
              </TableCell>
              <TableCell className="tnum hidden text-[12px] text-muted-foreground md:table-cell">
                {l.serialNumber != null ? `#${l.serialNumber}` : "—"}
              </TableCell>
              <TableCell className="text-[12px] text-foreground/80">@{l.seller?.username || "—"}</TableCell>
              {showStatus && (
                <TableCell className="hidden sm:table-cell">
                  <StatusBadge status={l.status} />
                </TableCell>
              )}
              <TableCell className="text-left">
                <PriceBadge amount={l.price} currency={l.currency} />
              </TableCell>
              <TableCell className="hidden text-left text-[11px] text-muted-foreground lg:table-cell">
                {timeAgoFa(l.createdAt)}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
