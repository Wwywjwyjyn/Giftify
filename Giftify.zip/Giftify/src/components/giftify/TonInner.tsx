"use client";

import { useState } from "react";
import { TonConnectUIProvider } from "@tonconnect/ui-react";

export default function TonInner({ children }: { children: React.ReactNode }) {
  // Rendered client-only (dynamic, ssr:false), so window is always available.
  const [manifest] = useState(() => `${window.location.origin}/api/tonconnect-manifest.json`);

  return (
    <TonConnectUIProvider manifestUrl={manifest} uiPreferences={{ borderRadius: "m" }}>
      {children}
    </TonConnectUIProvider>
  );
}
