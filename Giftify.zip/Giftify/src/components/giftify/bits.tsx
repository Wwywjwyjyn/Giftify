import { faDigits } from "@/lib/format";

export function PriceBadge({ amount, currency, size = "md" }: { amount: number; currency: string; size?: "sm" | "md" | "lg" }) {
  const text =
    currency === "STARS"
      ? `${faDigits(Math.round(amount).toLocaleString("en-US"))} ⭐`
      : `${faDigits(Number.isInteger(amount) ? amount : amount.toFixed(2))} TON`;
  const cls =
    size === "lg"
      ? "text-base px-3 py-1"
      : size === "sm"
        ? "text-[11px] px-1.5 py-0.5"
        : "text-xs px-2 py-0.5";
  return (
    <span
      className={`inline-flex items-center rounded-md border border-petrol/25 bg-petrol-ink/60 font-semibold text-petrol-bright tnum ${cls}`}
    >
      {text}
    </span>
  );
}

const STATUS_MAP: Record<string, { label: string; cls: string }> = {
  ACTIVE: { label: "در فروش", cls: "border-emerald-400/25 bg-emerald-400/10 text-emerald-300" },
  PENDING_SOLD: { label: "در انتظار تأیید", cls: "border-amber-400/25 bg-amber-400/10 text-amber-300" },
  SOLD: { label: "فروخته شد", cls: "border-petrol/25 bg-petrol/10 text-petrol-bright" },
  WITHDRAWN: { label: "برداشته شد", cls: "border-white/10 bg-white/5 text-muted-foreground" },
};

export function StatusBadge({ status }: { status: string }) {
  const s = STATUS_MAP[status] || { label: status, cls: "border-white/10 bg-white/5 text-muted-foreground" };
  return <span className={`inline-flex rounded-full border px-2 py-0.5 text-[11px] font-medium ${s.cls}`}>{s.label}</span>;
}

export function TxStatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; cls: string }> = {
    PENDING: { label: "در انتظار", cls: "border-amber-400/25 bg-amber-400/10 text-amber-300" },
    CONFIRMED: { label: "تأیید شده", cls: "border-emerald-400/25 bg-emerald-400/10 text-emerald-300" },
    CANCELLED: { label: "لغو شده", cls: "border-white/10 bg-white/5 text-muted-foreground" },
  };
  const s = map[status] || { label: status, cls: "border-white/10 bg-white/5 text-muted-foreground" };
  return <span className={`inline-flex rounded-full border px-2 py-0.5 text-[11px] font-medium ${s.cls}`}>{s.label}</span>;
}

export function SectionHeader({
  title,
  action,
  onAction,
}: {
  title: string;
  action?: string;
  onAction?: () => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <h2 className="text-sm font-bold tracking-wide text-foreground/90">{title}</h2>
      {action && (
        <button
          onClick={onAction}
          className="text-xs font-medium text-petrol-bright transition-colors hover:text-primary"
        >
          {action} ←
        </button>
      )}
    </div>
  );
}

export function EmptyState({ icon, title, hint, cta, onCta }: { icon: React.ReactNode; title: string; hint?: string; cta?: string; onCta?: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-border bg-card/40 px-6 py-12 text-center">
      <div className="mb-1 text-3xl opacity-60">{icon}</div>
      <p className="text-sm font-semibold text-foreground/80">{title}</p>
      {hint && <p className="max-w-sm text-xs leading-5 text-muted-foreground">{hint}</p>}
      {cta && (
        <button
          onClick={onCta}
          className="mt-2 rounded-lg bg-petrol px-4 py-2 text-xs font-bold text-primary-foreground transition hover:bg-petrol-deep"
        >
          {cta}
        </button>
      )}
    </div>
  );
}

export function StatBox({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col items-center gap-0.5 rounded-xl border border-border bg-card/60 px-3 py-3">
      <span className="tnum text-lg font-black text-foreground">{value}</span>
      <span className="text-[11px] text-muted-foreground">{label}</span>
    </div>
  );
}
