"use client";

import { PriceBadge, StatusBadge } from "@/components/giftify/bits";

export type GiftCardData = {
  id: string;
  title: string;
  emoji: string | null;
  currency: string;
  price: number;
  status: string;
  collection?: { name: string; emoji?: string | null } | null;
};

export default function GiftCard({ gift, onOpen }: { gift: GiftCardData; onOpen: (id: string) => void }) {
  const dim = gift.status !== "ACTIVE";
  return (
    <button
      onClick={() => onOpen(gift.id)}
      className={`group flex flex-col overflow-hidden rounded-xl border border-border bg-card text-right transition-all hover:border-petrol/40 hover:shadow-[0_0_24px_rgba(14,147,184,0.12)] ${dim ? "opacity-60" : ""}`}
    >
      <div className="relative grid aspect-[4/3] place-items-center bg-gradient-to-b from-petrol-ink/50 to-card">
        <span className="text-5xl transition-transform duration-200 group-hover:scale-110">
          {gift.emoji || "🎁"}
        </span>
        <span className="absolute top-2 left-2">
          <StatusBadge status={gift.status} />
        </span>
      </div>
      <div className="flex items-start justify-between gap-2 p-3">
        <div className="min-w-0">
          <p className="truncate text-[13px] font-bold text-foreground">{gift.title}</p>
          <p className="mt-0.5 truncate text-[11px] text-muted-foreground">
            {gift.collection?.name || "بدون مجموعه"}
          </p>
        </div>
        <PriceBadge amount={gift.price} currency={gift.currency} size="sm" />
      </div>
    </button>
  );
}
