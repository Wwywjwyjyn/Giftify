"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "@/lib/nav";
import { useApp } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { TxStatusBadge, StatBox, SectionHeader } from "@/components/giftify/bits";
import { toast } from "sonner";
import { faDigits, timeAgoFa } from "@/lib/format";
import {
  Shield,
  Percent,
  Wallet,
  Users,
  Tag,
  Send,
  Settings,
  RefreshCw,
  Trash2,
  Gift,
  Crown,
} from "lucide-react";

type Stats = {
  users: number;
  listingsTotal: number;
  listingsActive: number;
  listingsSold: number;
  pendingTxs: number;
  volumeTon: number;
  volumeStars: number;
  feesTon: number;
  feesStars: number;
  feeWallet: string | null;
  recent: {
    id: string;
    amount: number;
    currency: string;
    feeAmount: number;
    status: string;
    createdAt: string;
    listing: { title: string; emoji: string | null };
    buyer: { username: string } | null;
    seller: { username: string } | null;
  }[];
};

type AdminUser = {
  id: string;
  username: string;
  role: string;
  telegramName: string | null;
  tonWallet: string | null;
  createdAt: string;
  _count: { listings: number; purchases: number; sales: number };
};

type AdminListing = {
  id: string;
  title: string;
  emoji: string | null;
  price: number;
  currency: string;
  status: string;
  createdAt: string;
  seller: { username: string } | null;
  buyer: { username: string } | null;
};

const inputCls = "h-9 rounded-lg border-border bg-secondary text-[12px]";

export default function AdminView() {
  const router = useRouter();
  const user = useApp((s) => s.user);
  const authChecked = useApp((s) => s.authChecked);
  const refreshMe = useApp((s) => s.refreshMe);

  const [stats, setStats] = useState<Stats | null>(null);
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [listings, setListings] = useState<AdminListing[]>([]);
  const [tg, setTg] = useState<{ configured: boolean; authorized: boolean; phone: string; lastSync: string | null } | null>(null);
  const [tgForm, setTgForm] = useState({ apiId: "", apiHash: "", phone: "" });
  const [tgCode, setTgCode] = useState("");
  const [tgPassword, setTgPassword] = useState("");
  const [tgNeedPassword, setTgNeedPassword] = useState(false);
  const [busy, setBusy] = useState(false);

  const loadAll = useCallback(() => {
    fetch("/api/admin/stats").then((r) => r.json()).then(setStats).catch(() => {});
    fetch("/api/admin/settings").then((r) => r.json()).then((d) => d.settings && setSettings(d.settings)).catch(() => {});
    fetch("/api/admin/users").then((r) => r.json()).then((d) => setUsers(d.users || [])).catch(() => {});
    fetch("/api/admin/listings?status=all").then((r) => r.json()).then((d) => setListings(d.listings || [])).catch(() => {});
    fetch("/api/admin/telegram").then((r) => r.json()).then(setTg).catch(() => {});
  }, []);

  useEffect(() => {
    if (authChecked && user && user.role !== "ADMIN") {
      toast.error("دسترسی فقط برای مدیر سایت.");
      router.go("");
    }
  }, [authChecked, user, router]);

  useEffect(() => {
    if (user?.role === "ADMIN") loadAll();
  }, [user, loadAll]);

  if (!authChecked || !user || user.role !== "ADMIN")
    return <div className="mx-auto max-w-4xl px-4 py-16"><div className="h-64 animate-pulse rounded-2xl bg-card/60" /></div>;

  const saveSettings = async (patch: Record<string, string>, msg: string) => {
    setBusy(true);
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(patch),
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "خطا");
      setSettings(d.settings);
      toast.success(msg);
      refreshMe();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا");
    } finally {
      setBusy(false);
    }
  };

  const userAction = async (id: string, action: "make_admin" | "make_user" | "delete") => {
    try {
      let res: Response;
      if (action === "delete") res = await fetch(`/api/admin/users?id=${id}`, { method: "DELETE" });
      else
        res = await fetch("/api/admin/users", {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id, role: action === "make_admin" ? "ADMIN" : "USER" }),
        });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "خطا");
      toast.success("انجام شد");
      loadAll();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا");
    }
  };

  const listingAction = async (id: string, action: "activate" | "withdraw" | "delete") => {
    try {
      let res: Response;
      if (action === "delete") res = await fetch(`/api/admin/listings?id=${id}`, { method: "DELETE" });
      else
        res = await fetch("/api/admin/listings", {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id, status: action === "activate" ? "ACTIVE" : "WITHDRAWN" }),
        });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "خطا");
      toast.success("انجام شد");
      loadAll();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا");
    }
  };

  const tgAction = async (action: string, extra: Record<string, unknown> = {}) => {
    setBusy(true);
    try {
      const res = await fetch("/api/admin/telegram", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, ...extra }),
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "خطا");
      if (d.needPassword) {
        setTgNeedPassword(true);
        toast.info(d.message);
      } else {
        toast.success(d.message || "انجام شد");
        if (action === "verify") setTgNeedPassword(false);
        loadAll();
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-6">
      <div className="mb-4 flex items-center gap-2">
        <Shield className="size-5 text-petrol-bright" />
        <h1 className="text-lg font-black text-foreground">پنل مدیریت گیفتیفای</h1>
        <span className="rounded-full border border-petrol/30 bg-petrol-ink/50 px-2 py-0.5 text-[10px] font-bold text-petrol-bright">
          <Crown className="mr-1 inline size-3" />
          مالک
        </span>
      </div>

      <Tabs defaultValue="dashboard" dir="rtl">
        <TabsList className="flex h-auto w-full flex-wrap justify-start gap-1 bg-secondary p-1">
          {[
            { v: "dashboard", l: "داشبورد", i: Percent },
            { v: "fees", l: "کارمزد و کیف پول", i: Percent },
            { v: "listings", l: "آگهی‌ها", i: Tag },
            { v: "users", l: "کاربران", i: Users },
            { v: "telegram", l: "تلگرام", i: Send },
            { v: "site", l: "تنظیمات سایت", i: Settings },
          ].map((t) => (
            <TabsTrigger key={t.v} value={t.v} className="gap-1.5 text-[11px]">
              <t.i className="size-3.5" />
              {t.l}
            </TabsTrigger>
          ))}
        </TabsList>

        {/* Dashboard */}
        <TabsContent value="dashboard" className="mt-4 flex flex-col gap-5">
          <div className="grid grid-cols-2 gap-2.5 md:grid-cols-5">
            <StatBox label="کاربران" value={faDigits(stats?.users ?? 0)} />
            <StatBox label="آگهی فعال" value={faDigits(stats?.listingsActive ?? 0)} />
            <StatBox label="فروش موفق" value={faDigits(stats?.listingsSold ?? 0)} />
            <StatBox label="در انتظار" value={faDigits(stats?.pendingTxs ?? 0)} />
            <StatBox
              label="حجم فروش TON"
              value={faDigits((stats?.volumeTon ?? 0).toFixed(2))}
            />
          </div>

          <div className="rounded-xl border border-petrol/25 bg-petrol-ink/30 p-4">
            <p className="flex items-center gap-1.5 text-[13px] font-bold text-petrol-bright">
              <Wallet className="size-4" />
              کارمزد قابل وصول
            </p>
            <div className="mt-2 flex flex-wrap items-center gap-x-6 gap-y-1 text-[12px]">
              <span className="tnum text-foreground">
                {faDigits((stats?.feesTon ?? 0).toFixed(2))} TON
              </span>
              <span className="tnum text-foreground">
                {faDigits(Math.round(stats?.feesStars ?? 0).toLocaleString("en-US"))} ⭐
              </span>
            </div>
            <p className="mt-2 text-[11px] leading-5 text-muted-foreground" dir="ltr">
              {stats?.feeWallet ? `Fee wallet: ${stats.feeWallet}` : "کیف پول کارمزد هنوز تعیین نشده — از تب «کارمزد و کیف پول» تنظیم کنید."}
            </p>
          </div>

          <section className="flex flex-col gap-3">
            <SectionHeader title="آخرین تراکنش‌ها" />
            <div className="overflow-hidden rounded-xl border border-border">
              {stats?.recent?.length ? (
                stats.recent.map((t) => (
                  <div key={t.id} className="flex flex-wrap items-center justify-between gap-2 border-b border-border/60 p-3 last:border-0 text-[12px]">
                    <span className="flex items-center gap-2">
                      <span className="text-base">{t.listing.emoji || "🎁"}</span>
                      <span className="font-semibold">{t.listing.title}</span>
                    </span>
                    <span className="text-muted-foreground">
                      @{t.seller?.username} → @{t.buyer?.username}
                    </span>
                    <span className="flex items-center gap-2">
                      <TxStatusBadge status={t.status} />
                      <span className="tnum">{faDigits(t.amount)} {t.currency === "STARS" ? "⭐" : "TON"}</span>
                      <span className="tnum text-petrol-bright">کارمزد: {faDigits(t.feeAmount)}</span>
                      <span className="text-[10px] text-muted-foreground">{timeAgoFa(t.createdAt)}</span>
                    </span>
                  </div>
                ))
              ) : (
                <p className="p-6 text-center text-xs text-muted-foreground">هنوز تراکنشی ثبت نشده.</p>
              )}
            </div>
          </section>
        </TabsContent>

        {/* Fees & treasury wallet */}
        <TabsContent value="fees" className="mt-4">
          <div className="flex flex-col gap-4 rounded-2xl border border-border bg-card/50 p-5">
            <p className="text-[13px] font-bold text-foreground/90">کارمزد هر بخش (درصد)</p>
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="flex flex-col gap-1.5">
                <Label className="text-xs text-muted-foreground">کارمزد فروش</Label>
                <Input
                  type="number"
                  inputMode="decimal"
                  value={settings.fee_sale_percent ?? ""}
                  onChange={(e) => setSettings({ ...settings, fee_sale_percent: e.target.value })}
                  className={`${inputCls} tnum`}
                  dir="ltr"
                />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label className="text-xs text-muted-foreground">کارمزد انتقال / ترانسفر</Label>
                <Input
                  type="number"
                  inputMode="decimal"
                  value={settings.fee_transfer_percent ?? ""}
                  onChange={(e) => setSettings({ ...settings, fee_transfer_percent: e.target.value })}
                  className={`${inputCls} tnum`}
                  dir="ltr"
                />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label className="text-xs text-muted-foreground">کارمزد برداشت</Label>
                <Input
                  type="number"
                  inputMode="decimal"
                  value={settings.fee_withdraw_percent ?? ""}
                  onChange={(e) => setSettings({ ...settings, fee_withdraw_percent: e.target.value })}
                  className={`${inputCls} tnum`}
                  dir="ltr"
                />
              </div>
            </div>

            <p className="mt-2 text-[13px] font-bold text-foreground/90">کیف پول مقصد کارمزدها (Treasury)</p>
            <div className="flex flex-col gap-2 sm:flex-row">
              <Input
                value={settings.treasury_wallet ?? ""}
                onChange={(e) => setSettings({ ...settings, treasury_wallet: e.target.value })}
                placeholder="UQ… آدرس TON که کارمزدها به آن تعلق می‌گیرد"
                dir="ltr"
                className={`${inputCls} flex-1 text-left`}
              />
              <Button
                onClick={() =>
                  saveSettings(
                    {
                      fee_sale_percent: settings.fee_sale_percent,
                      fee_transfer_percent: settings.fee_transfer_percent,
                      fee_withdraw_percent: settings.fee_withdraw_percent,
                      treasury_wallet: settings.treasury_wallet,
                    },
                    "کارمزدها و کیف پول ذخیره شد"
                  )
                }
                disabled={busy}
                className="text-xs"
              >
                ذخیره
              </Button>
            </div>
            <p className="text-[11px] leading-5 text-muted-foreground">
              از این پس کارمزد هر معامله به همین کیف پول اختصاص می‌یابد و در تمام تراکنش‌ها به‌صورت شفاف نمایش داده می‌شود.
            </p>
          </div>
        </TabsContent>

        {/* Listings moderation */}
        <TabsContent value="listings" className="mt-4">
          <div className="overflow-x-auto rounded-xl border border-border">
            {listings.length === 0 ? (
              <p className="p-6 text-center text-xs text-muted-foreground">آگهی‌ای وجود ندارد.</p>
            ) : (
              listings.map((l) => (
                <div key={l.id} className="flex flex-wrap items-center justify-between gap-2 border-b border-border/60 p-3 last:border-0 text-[12px]">
                  <span className="flex items-center gap-2">
                    <span className="text-base">{l.emoji || "🎁"}</span>
                    <span className="font-semibold">{l.title}</span>
                    <span className="tnum text-petrol-bright">{faDigits(l.price)} {l.currency === "STARS" ? "⭐" : "TON"}</span>
                  </span>
                  <span className="text-muted-foreground">
                    @{l.seller?.username}
                    {l.buyer ? ` → خریدار: @${l.buyer.username}` : ""}
                  </span>
                  <span className="flex items-center gap-1.5">
                    {l.status === "WITHDRAWN" ? (
                      <Button size="sm" variant="outline" className="h-7 text-[11px]" onClick={() => listingAction(l.id, "activate")}>
                        فعال‌سازی
                      </Button>
                    ) : (
                      <Button size="sm" variant="outline" className="h-7 text-[11px]" onClick={() => listingAction(l.id, "withdraw")}>
                        برداشتن
                      </Button>
                    )}
                    <Button size="sm" variant="ghost" className="h-7 text-[11px] text-danger" onClick={() => listingAction(l.id, "delete")}>
                      <Trash2 className="size-3.5" />
                    </Button>
                  </span>
                </div>
              ))
            )}
          </div>
        </TabsContent>

        {/* Users */}
        <TabsContent value="users" className="mt-4">
          <div className="overflow-x-auto rounded-xl border border-border">
            {users.map((u) => (
              <div key={u.id} className="flex flex-wrap items-center justify-between gap-2 border-b border-border/60 p-3 last:border-0 text-[12px]">
                <span className="flex items-center gap-2">
                  <span className="font-semibold text-foreground">@{u.username}</span>
                  {u.role === "ADMIN" && (
                    <span className="rounded-full border border-petrol/30 bg-petrol-ink/50 px-1.5 py-0.5 text-[10px] font-bold text-petrol-bright">
                      مدیر
                    </span>
                  )}
                  {u.telegramName && <span className="text-muted-foreground">{u.telegramName}</span>}
                </span>
                <span className="tnum text-muted-foreground">
                  آگهی: {faDigits(u._count.listings)} — خرید: {faDigits(u._count.purchases)} — فروش: {faDigits(u._count.sales)}
                </span>
                <span className="flex items-center gap-1.5">
                  {u.role === "USER" ? (
                    <Button size="sm" variant="outline" className="h-7 text-[11px]" onClick={() => userAction(u.id, "make_admin")}>
                      مدیر کن
                    </Button>
                  ) : (
                    <Button size="sm" variant="outline" className="h-7 text-[11px]" onClick={() => userAction(u.id, "make_user")}>
                      سلب مدیریت
                    </Button>
                  )}
                  <Button size="sm" variant="ghost" className="h-7 text-[11px] text-danger" onClick={() => userAction(u.id, "delete")}>
                    <Trash2 className="size-3.5" />
                  </Button>
                </span>
              </div>
            ))}
          </div>
        </TabsContent>

        {/* Telegram MTProto */}
        <TabsContent value="telegram" className="mt-4">
          <div className="flex flex-col gap-4 rounded-2xl border border-border bg-card/50 p-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="flex items-center gap-1.5 text-[13px] font-bold text-foreground/90">
                <Send className="size-4 text-petrol-bright" />
                اتصال به تلگرام (بازار رسمی استارز)
              </p>
              <span className="text-[11px] text-muted-foreground">
                {tg?.authorized
                  ? `وصل شد ✓ ${tg.phone} — آخرین همگام‌سازی: ${tg.lastSync ? timeAgoFa(tg.lastSync) : "—"}`
                  : tg?.configured
                    ? "تنظیمات ذخیره شده — کد تأیید بگیرید."
                    : "وصل نیست."}
              </span>
            </div>
            <p className="text-[11px] leading-5 text-muted-foreground">
              api_id و api_hash را از <span dir="ltr" className="text-petrol-bright">my.telegram.org</span> بگیرید. بعد از ورود، دکمهٔ
              همگام‌سازی، فهرست هدیه‌های رسمی استارز تلگرام را در بازار شما بارگذاری می‌کند.
            </p>

            <div className="grid gap-3 sm:grid-cols-3">
              <div className="flex flex-col gap-1.5">
                <Label className="text-xs text-muted-foreground">api_id</Label>
                <Input value={tgForm.apiId} onChange={(e) => setTgForm({ ...tgForm, apiId: e.target.value.replace(/[^0-9]/g, "") })} className={`${inputCls} tnum`} dir="ltr" />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label className="text-xs text-muted-foreground">api_hash</Label>
                <Input value={tgForm.apiHash} onChange={(e) => setTgForm({ ...tgForm, apiHash: e.target.value })} className={`${inputCls}`} dir="ltr" />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label className="text-xs text-muted-foreground">شماره تلفن (+98…)</Label>
                <Input value={tgForm.phone} onChange={(e) => setTgForm({ ...tgForm, phone: e.target.value })} className={`${inputCls} tnum`} dir="ltr" />
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <Button size="sm" className="text-xs" disabled={busy} onClick={() => tgAction("save", tgForm)}>
                ذخیره تنظیمات
              </Button>
              <Button size="sm" variant="secondary" className="text-xs" disabled={busy} onClick={() => tgAction("send_code")}>
                دریافت کد تأیید
              </Button>
              <Button size="sm" variant="secondary" className="text-xs" disabled={busy} onClick={() => tgAction("sync")}>
                <RefreshCw className="size-3.5" />
                همگام‌سازی هدیه‌های رسمی
              </Button>
              {tg?.authorized && (
                <Button size="sm" variant="ghost" className="text-xs text-danger" disabled={busy} onClick={() => tgAction("logout")}>
                  حذف سشن
                </Button>
              )}
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <div className="flex flex-col gap-1.5">
                <Label className="text-xs text-muted-foreground">کد تأیید تلگرام</Label>
                <Input value={tgCode} onChange={(e) => setTgCode(e.target.value)} className={`${inputCls} tnum`} dir="ltr" placeholder="12345" />
              </div>
              {tgNeedPassword && (
                <div className="flex flex-col gap-1.5">
                  <Label className="text-xs text-muted-foreground">رمز دو مرحله‌ای</Label>
                  <Input type="password" value={tgPassword} onChange={(e) => setTgPassword(e.target.value)} className={inputCls} dir="ltr" />
                </div>
              )}
            </div>
            <Button size="sm" className="self-start text-xs" disabled={busy || !tgCode} onClick={() => tgAction("verify", { code: tgCode, password: tgPassword || undefined })}>
              تأیید و ورود
            </Button>
          </div>
        </TabsContent>

        {/* Site settings */}
        <TabsContent value="site" className="mt-4">
          <div className="flex flex-col gap-4 rounded-2xl border border-border bg-card/50 p-5">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="flex flex-col gap-1.5">
                <Label className="text-xs text-muted-foreground">نام سایت</Label>
                <Input value={settings.site_name ?? ""} onChange={(e) => setSettings({ ...settings, site_name: e.target.value })} className={inputCls} />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label className="text-xs text-muted-foreground">شعار صفحهٔ اصلی</Label>
                <Input value={settings.site_tagline ?? ""} onChange={(e) => setSettings({ ...settings, site_tagline: e.target.value })} className={inputCls} />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label className="text-xs text-muted-foreground">حداقل قیمت TON</Label>
                <Input
                  type="number"
                  value={settings.min_price_ton ?? ""}
                  onChange={(e) => setSettings({ ...settings, min_price_ton: e.target.value })}
                  className={`${inputCls} tnum`}
                  dir="ltr"
                />
              </div>
              <div className="flex items-center justify-between rounded-lg border border-border bg-secondary px-3 py-2">
                <span className="text-[12px] text-foreground/90">ثبت‌نام باز باشد</span>
                <Switch
                  checked={settings.allow_registration !== "0"}
                  onCheckedChange={(v) => setSettings({ ...settings, allow_registration: v ? "1" : "0" })}
                />
              </div>
            </div>
            <Button
              className="self-start text-xs"
              disabled={busy}
              onClick={() =>
                saveSettings(
                  {
                    site_name: settings.site_name,
                    site_tagline: settings.site_tagline,
                    min_price_ton: settings.min_price_ton,
                    allow_registration: settings.allow_registration,
                  },
                  "تنظیمات ذخیره شد"
                )
              }
            >
              <Gift className="size-3.5" />
              ذخیره تنظیمات سایت
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
