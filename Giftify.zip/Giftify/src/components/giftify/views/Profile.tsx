"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "@/lib/nav";
import { useApp } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import GiftTable, { type ListingRow } from "@/components/giftify/GiftTable";
import { TxStatusBadge, EmptyState } from "@/components/giftify/bits";
import { toast } from "sonner";
import { faDigits, timeAgoFa } from "@/lib/format";
import { Wallet, LogOut, Shield, RefreshCw, Check, X } from "lucide-react";

type Tx = {
  id: string;
  amount: number;
  currency: string;
  feeAmount: number;
  feePercent: number;
  status: string;
  method: string | null;
  txHash: string | null;
  createdAt: string;
  listing: { id: string; title: string; emoji: string | null };
  buyer: { id: string; username: string } | null;
  seller: { id: string; username: string } | null;
};

export default function ProfileView() {
  const router = useRouter();
  const user = useApp((s) => s.user);
  const authChecked = useApp((s) => s.authChecked);
  const settings = useApp((s) => s.settings);
  const refreshMe = useApp((s) => s.refreshMe);
  const [wallet, setWallet] = useState("");
  const [listings, setListings] = useState<ListingRow[]>([]);
  const [txs, setTxs] = useState<{ asSeller: Tx[]; asBuyer: Tx[] }>({ asSeller: [], asBuyer: [] });
  const [saving, setSaving] = useState(false);

  const load = useCallback(() => {
    if (!user) return;
    setWallet(user.tonWallet || "");
    fetch("/api/listings?mine=1&status=all&limit=100")
      .then((r) => r.json())
      .then((d) => setListings(d.listings || []))
      .catch(() => {});
    fetch("/api/transactions/mine")
      .then((r) => r.json())
      .then((d) => setTxs({ asSeller: d.asSeller || [], asBuyer: d.asBuyer || [] }))
      .catch(() => {});
  }, [user]);

  useEffect(load, [load]);

  if (!authChecked)
    return <div className="mx-auto max-w-4xl px-4 py-16"><div className="h-64 animate-pulse rounded-2xl bg-card/60" /></div>;

  if (!user)
    return (
      <div className="mx-auto max-w-md px-4 py-16 text-center">
        <p className="mb-4 text-sm text-muted-foreground">برای دیدن حساب باید وارد شوید.</p>
        <Button onClick={() => router.go("auth")}>ورود / ثبت‌نام</Button>
      </div>
    );

  const saveWallet = async () => {
    setSaving(true);
    try {
      const res = await fetch("/api/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tonWallet: wallet.trim() }),
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "خطا");
      toast.success("کیف پول ذخیره شد");
      refreshMe();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا");
    } finally {
      setSaving(false);
    }
  };

  const listingAction = async (id: string, status: "WITHDRAWN" | "ACTIVE") => {
    const res = await fetch(`/api/listings/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    const d = await res.json();
    if (!res.ok) return toast.error(d.error || "خطا");
    toast.success("انجام شد");
    load();
  };

  const deleteListing = async (id: string) => {
    const res = await fetch(`/api/listings/${id}`, { method: "DELETE" });
    const d = await res.json();
    if (!res.ok) return toast.error(d.error || "خطا");
    toast.success("آگهی حذف شد");
    load();
  };

  const txAction = async (id: string, action: "confirm" | "cancel") => {
    const res = await fetch(`/api/transactions/${id}/${action}`, { method: "POST" });
    const d = await res.json();
    if (!res.ok) return toast.error(d.error || "خطا");
    toast.success(action === "confirm" ? "تأیید شد 🎉" : "لغو شد");
    load();
  };

  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    await refreshMe();
    router.go("");
  };

  const pendingSales = txs.asSeller.filter((t) => t.status === "PENDING");

  return (
    <div className="mx-auto flex max-w-4xl flex-col gap-6 px-4 py-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-black text-foreground">حساب من — @{user.username}</h1>
          <p className="mt-0.5 text-[11px] text-muted-foreground">
            {user.telegramName ? `تلگرام: ${user.telegramName}` : "حساب وب"}
          </p>
        </div>
        <div className="flex gap-2">
          {user.role === "ADMIN" && (
            <Button variant="secondary" size="sm" onClick={() => router.go("admin")} className="gap-1.5 text-xs">
              <Shield className="size-3.5" />
              پنل مدیریت
            </Button>
          )}
          <Button variant="outline" size="sm" onClick={logout} className="gap-1.5 text-xs">
            <LogOut className="size-3.5" />
            خروج
          </Button>
        </div>
      </div>

      {/* Wallet */}
      <section className="rounded-2xl border border-border bg-card/50 p-4">
        <p className="mb-2 flex items-center gap-1.5 text-[13px] font-bold text-foreground/90">
          <Wallet className="size-4 text-petrol-bright" />
          کیف پول TON برای دریافت پرداخت
        </p>
        <div className="flex flex-col gap-2 sm:flex-row">
          <Input
            value={wallet}
            onChange={(e) => setWallet(e.target.value)}
            placeholder="UQ… آدرس TON شما"
            dir="ltr"
            className="h-10 flex-1 border-border bg-secondary text-left text-[12px]"
          />
          <Button onClick={saveWallet} disabled={saving} size="sm" className="h-10 px-4 text-xs">
            ذخیره
          </Button>
        </div>
        <p className="mt-2 text-[11px] leading-5 text-muted-foreground">
          پرداخت خریداران مستقیم به این آدرس انجام می‌شود؛ کارمزد {faDigits(settings?.fee_sale_percent ?? 5)}٪ فروش به‌صورت
          شفاف در هر تراکنش ثبت و به کیف پول کارمزد سایت اختصاص می‌یابد.
        </p>
      </section>

      {/* Pending sales */}
      {pendingSales.length > 0 && (
        <section className="rounded-2xl border border-amber-400/25 bg-amber-400/5 p-4">
          <p className="mb-3 text-[13px] font-bold text-amber-300">فروش‌های در انتظار تأیید شما</p>
          <div className="flex flex-col gap-2">
            {pendingSales.map((t) => (
              <div
                key={t.id}
                className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-border bg-card p-3"
              >
                <div className="flex items-center gap-2 text-[12px]">
                  <span className="text-lg">{t.listing.emoji || "🎁"}</span>
                  <span className="font-semibold">{t.listing.title}</span>
                  <span className="text-muted-foreground">خریدار: @{t.buyer?.username}</span>
                  <span className="tnum text-petrol-bright">
                    {faDigits(t.amount)} {t.currency === "STARS" ? "⭐" : "TON"}
                  </span>
                </div>
                <div className="flex gap-1.5">
                  <Button size="sm" className="h-8 gap-1 text-xs" onClick={() => txAction(t.id, "confirm")}>
                    <Check className="size-3.5" />
                    تأیید فروش
                  </Button>
                  <Button size="sm" variant="outline" className="h-8 gap-1 text-xs" onClick={() => txAction(t.id, "cancel")}>
                    <X className="size-3.5" />
                    لغو
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* My listings */}
      <section className="flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-foreground/90">آگهی‌های من ({faDigits(listings.length)})</h2>
          <Button variant="ghost" size="sm" className="h-7 gap-1 text-[11px]" onClick={load}>
            <RefreshCw className="size-3" />
            تازه‌سازی
          </Button>
        </div>
        {listings.length === 0 ? (
          <EmptyState
            icon="🏷️"
            title="هنوز آگهی‌ای ندارید"
            cta="ثبت اولین آگهی"
            onCta={() => router.go("sell")}
          />
        ) : (
          <div className="flex flex-col gap-2">
            {listings.map((l) => (
              <div
                key={l.id}
                className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-border bg-card/50 p-3"
              >
                <button onClick={() => router.go(`gift/${l.id}`)} className="flex items-center gap-2 text-right">
                  <span className="grid size-9 place-items-center rounded-lg bg-petrol-ink/40 text-lg">{l.emoji || "🎁"}</span>
                  <div>
                    <p className="text-[13px] font-semibold text-foreground">{l.title}</p>
                    <p className="tnum text-[11px] text-petrol-bright">
                      {faDigits(l.price)} {l.currency === "STARS" ? "⭐" : "TON"}
                    </p>
                  </div>
                </button>
                <div className="flex items-center gap-1.5">
                  {l.status === "ACTIVE" ? (
                    <Button variant="outline" size="sm" className="h-7 text-[11px]" onClick={() => listingAction(l.id, "WITHDRAWN")}>
                      برداشتن
                    </Button>
                  ) : l.status === "WITHDRAWN" ? (
                    <Button variant="outline" size="sm" className="h-7 text-[11px]" onClick={() => listingAction(l.id, "ACTIVE")}>
                      فعال‌سازی
                    </Button>
                  ) : null}
                  {l.status !== "PENDING_SOLD" && (
                    <Button variant="ghost" size="sm" className="h-7 text-[11px] text-danger" onClick={() => deleteListing(l.id)}>
                      حذف
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Purchases */}
      <section className="flex flex-col gap-3">
        <h2 className="text-sm font-bold text-foreground/90">خریدهای من</h2>
        {txs.asBuyer.length === 0 ? (
          <EmptyState icon="🛒" title="هنوز خریدی انجام نداده‌اید" cta="رفتن به بازار" onCta={() => router.go("market")} />
        ) : (
          <div className="flex flex-col gap-2">
            {txs.asBuyer.map((t) => (
              <div key={t.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-border bg-card/50 p-3">
                <button className="flex items-center gap-2" onClick={() => router.go(`gift/${t.listing.id}`)}>
                  <span className="text-lg">{t.listing.emoji || "🎁"}</span>
                  <span className="text-[13px] font-semibold">{t.listing.title}</span>
                </button>
                <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
                  <TxStatusBadge status={t.status} />
                  <span className="tnum">{faDigits(t.amount)} {t.currency === "STARS" ? "⭐" : "TON"}</span>
                  <span>{timeAgoFa(t.createdAt)}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
