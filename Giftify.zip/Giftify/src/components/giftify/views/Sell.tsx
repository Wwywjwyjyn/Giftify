"use client";

import { useEffect, useState } from "react";
import { useRouter } from "@/lib/nav";
import { useApp } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { PackagePlus } from "lucide-react";

type Collection = { slug: string; name: string; emoji: string | null; activeCount: number };

export default function SellView() {
  const router = useRouter();
  const user = useApp((s) => s.user);
  const authChecked = useApp((s) => s.authChecked);
  const [collections, setCollections] = useState<Collection[]>([]);
  const [collectionMode, setCollectionMode] = useState<string>("none");
  const [newCollection, setNewCollection] = useState("");
  const [form, setForm] = useState({
    title: "",
    emoji: "",
    serialNumber: "",
    currency: "TON",
    price: "",
    description: "",
  });
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    fetch("/api/collections")
      .then((r) => r.json())
      .then((d) => setCollections(d.collections || []))
      .catch(() => {});
  }, []);

  if (!authChecked)
    return <div className="mx-auto max-w-2xl px-4 py-16"><div className="h-64 animate-pulse rounded-2xl bg-card/60" /></div>;

  if (!user)
    return (
      <div className="mx-auto max-w-md px-4 py-16 text-center">
        <p className="mb-4 text-sm text-muted-foreground">برای ثبت آگهی باید وارد حساب شوید.</p>
        <Button onClick={() => router.go("auth")}>ورود / ثبت‌نام</Button>
      </div>
    );

  const submit = async () => {
    setBusy(true);
    try {
      const payload: Record<string, unknown> = {
        title: form.title,
        emoji: form.emoji,
        currency: form.currency,
        price: form.price,
        description: form.description,
        serialNumber: form.serialNumber || undefined,
      };
      if (collectionMode === "new") payload.collectionName = newCollection;
      else if (collectionMode !== "none") {
        const col = collections.find((c) => c.slug === collectionMode);
        payload.collectionName = col?.name;
        payload.collectionSlug = col?.slug;
      }
      const res = await fetch("/api/listings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "خطا در ثبت آگهی");
      toast.success("آگهی ثبت شد 🎉");
      router.go(`gift/${d.listing.id}`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا در ثبت آگهی");
    } finally {
      setBusy(false);
    }
  };

  const inputCls = "h-10 rounded-lg border-border bg-secondary";

  return (
    <div className="mx-auto max-w-2xl px-4 py-6">
      <h1 className="mb-1 text-lg font-black text-foreground">ثبت آگهی فروش هدیه</h1>
      <p className="mb-5 text-xs leading-5 text-muted-foreground">
        هدیهٔ تلگرام خود را در گیفتیفای بفروشید. پرداخت خریدار مستقیم به کیف پول شما انجام می‌شود و کارمزد سایت شفاف
        محاسبه می‌گردد. برای دریافت پرداخت TON، آدرس کیف پول را در «حساب من» ثبت کنید.
      </p>

      <div className="flex flex-col gap-4 rounded-2xl border border-border bg-card/50 p-5">
        <div className="grid gap-4 sm:grid-cols-[1fr_110px]">
          <div className="flex flex-col gap-1.5">
            <Label className="text-xs text-muted-foreground">نام هدیه *</Label>
            <Input
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              placeholder="مثلاً: Plush Pepe شماره ۲۱"
              className={inputCls}
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label className="text-xs text-muted-foreground">ایموجی</Label>
            <Input
              value={form.emoji}
              onChange={(e) => setForm({ ...form, emoji: e.target.value })}
              placeholder="🎁"
              className={`${inputCls} text-center text-lg`}
            />
          </div>
        </div>

        <div className="flex flex-col gap-1.5">
          <Label className="text-xs text-muted-foreground">مجموعه</Label>
          <Select value={collectionMode} onValueChange={setCollectionMode}>
            <SelectTrigger className={inputCls}>
              <SelectValue placeholder="انتخاب مجموعه" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="none">بدون مجموعه</SelectItem>
              {collections.map((c) => (
                <SelectItem key={c.slug} value={c.slug}>
                  {c.emoji ? `${c.emoji} ` : ""}
                  {c.name}
                </SelectItem>
              ))}
              <SelectItem value="new">➕ مجموعهٔ جدید…</SelectItem>
            </SelectContent>
          </Select>
          {collectionMode === "new" && (
            <Input
              value={newCollection}
              onChange={(e) => setNewCollection(e.target.value)}
              placeholder="نام مجموعهٔ جدید"
              className={`${inputCls} mt-1`}
            />
          )}
        </div>

        <div className="grid gap-4 sm:grid-cols-3">
          <div className="flex flex-col gap-1.5">
            <Label className="text-xs text-muted-foreground">شمارهٔ سری (اختیاری)</Label>
            <Input
              value={form.serialNumber}
              onChange={(e) => setForm({ ...form, serialNumber: e.target.value.replace(/[^0-9]/g, "") })}
              placeholder="۲۱"
              className={`${inputCls} tnum`}
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label className="text-xs text-muted-foreground">واحد قیمت</Label>
            <Select value={form.currency} onValueChange={(v) => setForm({ ...form, currency: v })}>
              <SelectTrigger className={inputCls}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="TON">TON</SelectItem>
                <SelectItem value="STARS">⭐ استارز</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-col gap-1.5">
            <Label className="text-xs text-muted-foreground">قیمت *</Label>
            <Input
              value={form.price}
              onChange={(e) => setForm({ ...form, price: e.target.value.replace(/[^0-9.]/g, "") })}
              placeholder="0.00"
              className={`${inputCls} tnum text-left`}
              dir="ltr"
            />
          </div>
        </div>

        <div className="flex flex-col gap-1.5">
          <Label className="text-xs text-muted-foreground">توضیحات</Label>
          <Textarea
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            placeholder="جزئیات هدیه، شرایط انتقال و…"
            className="min-h-20 rounded-lg border-border bg-secondary text-[13px]"
          />
        </div>

        <Button onClick={submit} disabled={busy || form.title.trim().length < 2 || !form.price} className="mt-1 gap-2">
          <PackagePlus className="size-4" />
          {busy ? "در حال ثبت…" : "ثبت آگهی"}
        </Button>
        <p className="text-[11px] text-muted-foreground">
          کارمزد فروش روی هر معامله در زمان خرید محاسبه و در صفحهٔ آگهی شفاف نمایش داده می‌شود.
        </p>
      </div>
    </div>
  );
}
