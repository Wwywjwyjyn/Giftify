"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "@/lib/nav";
import { useApp } from "@/lib/store";
import GiftTable, { type ListingRow } from "@/components/giftify/GiftTable";
import GiftCard from "@/components/giftify/GiftCard";
import FiltersBar, { DEFAULT_FILTERS, type Filters } from "@/components/giftify/FiltersBar";
import { EmptyState } from "@/components/giftify/bits";
import { Button } from "@/components/ui/button";
import { faDigits } from "@/lib/format";
import { PackageOpen, LayoutGrid, TableProperties } from "lucide-react";

type Collection = { slug: string; name: string; emoji: string | null; activeCount: number };

export default function MarketView() {
  const router = useRouter();
  const route = useApp((s) => s.route);
  const [listings, setListings] = useState<ListingRow[]>([]);
  const [total, setTotal] = useState(0);
  const [collections, setCollections] = useState<Collection[]>([]);
  const [view, setView] = useState<"table" | "grid">("table");
  const [loading, setLoading] = useState(true);
  const [limit, setLimit] = useState(50);
  const debounce = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Sync filters from the URL hash so links/filters are shareable (adjust-during-render pattern)
  const paramKey = route.params.toString();
  const parseFilters = useCallback((sp: URLSearchParams): Filters => ({
    q: sp.get("q") || "",
    collection: sp.get("collection") || "",
    currency: sp.get("currency") || "",
    status: sp.get("status") || "ACTIVE",
    sort: sp.get("sort") || "newest",
    min: sp.get("min") || "",
    max: sp.get("max") || "",
  }), []);
  const [prevKey, setPrevKey] = useState(paramKey);
  const [filters, setFilters] = useState<Filters>(() => parseFilters(route.params));
  if (paramKey !== prevKey) {
    setPrevKey(paramKey);
    setFilters(parseFilters(route.params));
  }

  const pushParams = useCallback(
    (f: Filters) => {
      const params: Record<string, string> = {};
      if (f.q) params.q = f.q;
      if (f.collection) params.collection = f.collection;
      if (f.currency) params.currency = f.currency;
      if (f.status) params.status = f.status;
      if (f.sort && f.sort !== "newest") params.sort = f.sort;
      if (f.min) params.min = f.min;
      if (f.max) params.max = f.max;
      router.go("market", params);
    },
    [router]
  );

  const applyPatch = (patch: Partial<Filters>) => {
    const next = { ...filters, ...patch };
    setFilters(next);
    setLoading(true);
    if (debounce.current) clearTimeout(debounce.current);
    debounce.current = setTimeout(() => pushParams(next), 350);
  };

  useEffect(() => {
    let alive = true;
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([k, v]) => v && params.set(k, v));
    params.set("limit", String(limit));
    fetch(`/api/listings?${params.toString()}`)
      .then((r) => r.json())
      .then((d) => {
        if (!alive) return;
        setListings(d.listings || []);
        setTotal(d.total || 0);
        setLoading(false);
      })
      .catch(() => {})
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [filters, limit]);

  useEffect(() => {
    fetch("/api/collections")
      .then((r) => r.json())
      .then((d) => setCollections(d.collections || []))
      .catch(() => {});
  }, []);

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-4 px-4 py-6">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-black text-foreground">بازار هدیه‌ها</h1>
        <div className="flex items-center gap-2">
          <span className="tnum text-[11px] text-muted-foreground">
            {faDigits(total)} آگهی
          </span>
          <div className="flex overflow-hidden rounded-lg border border-border">
            <button
              onClick={() => setView("table")}
              className={`p-1.5 ${view === "table" ? "bg-accent text-accent-foreground" : "text-muted-foreground"}`}
              aria-label="نمای جدول"
            >
              <TableProperties className="size-4" />
            </button>
            <button
              onClick={() => setView("grid")}
              className={`p-1.5 ${view === "grid" ? "bg-accent text-accent-foreground" : "text-muted-foreground"}`}
              aria-label="نمای شبکه‌ای"
            >
              <LayoutGrid className="size-4" />
            </button>
          </div>
        </div>
      </div>

      <FiltersBar
        value={filters}
        collections={collections}
        onChange={applyPatch}
        onReset={() => {
          setFilters(DEFAULT_FILTERS);
          router.go("market");
        }}
      />

      {loading ? (
        <div className="grid gap-3 py-8 md:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="h-40 animate-pulse rounded-xl bg-card/60" />
          ))}
        </div>
      ) : listings.length === 0 ? (
        <EmptyState
          icon={<PackageOpen className="size-8 text-petrol-bright/60" />}
          title="آگهی‌ای با این فیلترها پیدا نشد"
          hint="فیلترها را تغییر دهید یا اولین آگهی این دسته را ثبت کنید."
          cta="ثبت آگهی"
          onCta={() => router.go("sell")}
        />
      ) : view === "table" ? (
        <GiftTable listings={listings} onOpen={(id) => router.go(`gift/${id}`)} />
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {listings.map((l) => (
            <GiftCard key={l.id} gift={l} onOpen={(id) => router.go(`gift/${id}`)} />
          ))}
        </div>
      )}

      {!loading && listings.length < total && (
        <Button variant="outline" onClick={() => setLimit((n) => n + 50)} className="mx-auto mt-2 text-xs">
          نمایش بیشتر
        </Button>
      )}
    </div>
  );
}
