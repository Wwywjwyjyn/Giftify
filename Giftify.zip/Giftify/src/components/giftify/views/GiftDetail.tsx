"use client";

import { useCallback, useEffect, useState } from "react";
import { useTonConnectUI } from "@tonconnect/ui-react";
import { useRouter } from "@/lib/nav";
import { useApp } from "@/lib/store";
import { PriceBadge, StatusBadge, TxStatusBadge } from "@/components/giftify/bits";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { faDigits, timeAgoFa } from "@/lib/format";
import { Wallet, Copy, BadgeCheck, ArrowRight } from "lucide-react";

type Detail = {
  id: string;
  title: string;
  emoji: string | null;
  serialNumber: number | null;
  currency: string;
  price: number;
  description: string | null;
  status: string;
  createdAt: string;
  seller: { id: string; username: string; tonWallet: string | null; telegramName?: string | null };
  buyer?: { id: string; username: string } | null;
  collection?: { name: string; slug: string; emoji: string | null } | null;
  transactions: { id: string; status: string; amount: number; currency: string; createdAt: string }[];
};

export default function GiftDetailView({ id }: { id: string }) {
  const router = useRouter();
  const user = useApp((s) => s.user);
  const settings = useApp((s) => s.settings);
  const refreshMe = useApp((s) => s.refreshMe);
  const [tonConnectUI] = useTonConnectUI();
  const [listing, setListing] = useState<Detail | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [buyOpen, setBuyOpen] = useState(false);
  const [step, setStep] = useState<"pay" | "done">("pay");
  const [txHash, setTxHash] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(() => {
    fetch(`/api/listings/${id}`)
      .then((r) => (r.ok ? r.json() : Promise.reject()))
      .then((d) => setListing(d.listing))
      .catch(() => setNotFound(true));
  }, [id]);

  useEffect(load, [load]);

  if (notFound)
    return (
      <div className="mx-auto max-w-3xl px-4 py-16 text-center text-sm text-muted-foreground">
        این آگهی پیدا نشد یا حذف شده است.
        <Button variant="link" onClick={() => router.go("market")} className="mr-1 text-petrol-bright">
          بازگشت به بازار
        </Button>
      </div>
    );
  if (!listing)
    return (
      <div className="mx-auto max-w-6xl px-4 py-10">
        <div className="h-72 animate-pulse rounded-2xl bg-card/60" />
      </div>
    );

  const isOwner = user?.id === listing.seller.id;
  const isAdmin = user?.role === "ADMIN";
  const feePercent = settings?.fee_sale_percent ?? 5;
  const feeAmount = Math.round(listing.price * feePercent) / 100;
  const pendingTx = listing.transactions.find((t) => t.status === "PENDING");
  const canBuy = listing.status === "ACTIVE" && user && !isOwner;

  const createTx = async (method: string, hash?: string) => {
    setBusy(true);
    try {
      const res = await fetch(`/api/listings/${listing.id}/buy`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ method, txHash: hash }),
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "خطا در ثبت سفارش");
      toast.success("سفارش ثبت شد — در انتظار تأیید فروشنده");
      setStep("done");
      load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا در ثبت سفارش");
    } finally {
      setBusy(false);
    }
  };

  const payWithWallet = async () => {
    if (!listing.seller.tonWallet) {
      toast.error("فروشنده کیف پول TON ثبت نکرده است.");
      return;
    }
    setBusy(true);
    try {
      await tonConnectUI.sendTransaction({
        validUntil: Math.floor(Date.now() / 1000) + 600,
        messages: [
          {
            address: listing.seller.tonWallet,
            amount: String(Math.round(listing.price * 1e9)),
          },
        ],
      });
      await createTx("ton_wallet");
    } catch (e) {
      if (!(e instanceof Error && e.message === "Transaction was not sent")) {
        if (String(e).includes("not sent") || String(e).includes("Cancel")) {
          toast.info("پرداخت لغو شد.");
        } else {
          toast.error("پرداخت انجام نشد.");
        }
      }
    } finally {
      setBusy(false);
    }
  };

  const ownerAction = async (status: "WITHDRAWN" | "ACTIVE") => {
    const res = await fetch(`/api/listings/${listing.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    const d = await res.json();
    if (!res.ok) return toast.error(d.error || "خطا");
    toast.success("انجام شد");
    load();
  };

  const txAction = async (txId: string, action: "confirm" | "cancel") => {
    const res = await fetch(`/api/transactions/${txId}/${action}`, { method: "POST" });
    const d = await res.json();
    if (!res.ok) return toast.error(d.error || "خطا");
    toast.success(action === "confirm" ? "فروش تأیید شد 🎉" : "معامله لغو شد");
    refreshMe();
    load();
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-6">
      <button
        onClick={() => router.go("market")}
        className="mb-4 flex items-center gap-1 text-xs text-muted-foreground transition hover:text-petrol-bright"
      >
        <ArrowRight className="size-3.5" />
        بازگشت به بازار
      </button>

      <div className="grid gap-5 md:grid-cols-[280px_1fr]">
        {/* Visual */}
        <div className="flex flex-col items-center gap-3">
          <div className="grid aspect-square w-full max-w-72 place-items-center rounded-2xl border border-petrol/20 bg-gradient-to-b from-petrol-ink/60 to-card text-8xl">
            {listing.emoji || "🎁"}
          </div>
          {listing.collection && (
            <button
              onClick={() => router.go("market", { collection: listing.collection!.slug })}
              className="text-xs text-petrol-bright transition hover:underline"
            >
              مجموعه: {listing.collection.emoji} {listing.collection.name}
            </button>
          )}
        </div>

        {/* Info */}
        <div className="flex flex-col gap-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h1 className="text-xl font-black text-foreground">{listing.title}</h1>
              <p className="mt-1 text-xs text-muted-foreground">
                @{listing.seller.username}
                {listing.seller.tonWallet && (
                  <span className="mr-1 inline-flex items-center gap-0.5 text-petrol-bright" title="کیف پول TON ثبت شده">
                    <BadgeCheck className="size-3.5" />
                  </span>
                )}
                {listing.serialNumber != null && (
                  <span className="tnum mr-2">شمارهٔ سری: {faDigits(listing.serialNumber)}</span>
                )}
                <span className="mr-2">{timeAgoFa(listing.createdAt)}</span>
              </p>
            </div>
            <div className="flex items-center gap-2">
              <StatusBadge status={listing.status} />
              <PriceBadge amount={listing.price} currency={listing.currency} size="lg" />
            </div>
          </div>

          {listing.description && (
            <div className="rounded-xl border border-border bg-card/50 p-4 text-[13px] leading-6 text-foreground/85">
              {listing.description}
            </div>
          )}

          {/* Actions */}
          {(canBuy || (!user && listing.status === "ACTIVE") || isOwner || (pendingTx && (isOwner || isAdmin))) && (
          <div className="flex flex-col gap-3 rounded-xl border border-border bg-card/50 p-4">
            {canBuy && (
              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between text-[12px]">
                  <span className="text-muted-foreground">کارمزد فروش پلتفرم</span>
                  <span className="tnum text-petrol-bright">
                    {faDigits(feePercent)}٪ ≈ {faDigits(feeAmount.toFixed(2))} {listing.currency === "STARS" ? "⭐" : "TON"}
                  </span>
                </div>
                <p className="text-[11px] leading-5 text-muted-foreground">
                  پرداخت شما مستقیم به کیف پول فروشنده انجام می‌شود؛ کارمزد سایت شفاف در تراکنش ثبت و به کیف پول کارمزد
                  تعیین‌شده توسط مدیریت اختصاص می‌یابد.
                </p>
                <Button onClick={() => { setStep("pay"); setBuyOpen(true); }} className="w-full gap-2">
                  <Wallet className="size-4" />
                  {listing.currency === "STARS" ? "خرید با استارز" : "خرید و پرداخت TON"}
                </Button>
              </div>
            )}

            {!user && listing.status === "ACTIVE" && (
              <Button onClick={() => router.go("auth")} className="w-full">
                برای خرید وارد حساب شوید
              </Button>
            )}

            {isOwner && listing.status === "ACTIVE" && (
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => ownerAction("WITHDRAWN")} className="flex-1 text-xs">
                  برداشتن از فروش
                </Button>
              </div>
            )}
            {isOwner && listing.status === "WITHDRAWN" && (
              <Button variant="outline" onClick={() => ownerAction("ACTIVE")} className="w-full text-xs">
                فعال‌سازی مجدد آگهی
              </Button>
            )}

            {pendingTx && (isOwner || isAdmin) && (
              <div className="flex flex-col gap-2 rounded-lg border border-amber-400/20 bg-amber-400/5 p-3">
                <p className="text-[12px] font-semibold text-amber-300">
                  معامله در جریان — بعد از انتقال هدیه در تلگرام، تأیید بزنید.
                </p>
                <div className="flex gap-2">
                  <Button onClick={() => txAction(pendingTx.id, "confirm")} className="flex-1 text-xs" disabled={busy}>
                    تأیید فروش
                  </Button>
                  <Button variant="outline" onClick={() => txAction(pendingTx.id, "cancel")} className="flex-1 text-xs">
                    لغو معامله
                  </Button>
                </div>
              </div>
            )}
            {pendingTx && user && pendingTx.status === "PENDING" && listing.buyer?.id === user.id && !isOwner && (
              <div className="flex flex-col gap-2 rounded-lg border border-amber-400/20 bg-amber-400/5 p-3">
                <p className="text-[12px] text-amber-300">سفارش شما ثبت شد و منتظر تأیید فروشنده است.</p>
                <Button variant="outline" onClick={() => txAction(pendingTx.id, "cancel")} className="text-xs">
                  لغو سفارش من
                </Button>
              </div>
            )}
          </div>
          )}

          {listing.transactions.length > 0 && (
            <div className="rounded-xl border border-border bg-card/40 p-4">
              <p className="mb-2 text-xs font-bold text-foreground/80">تاریخچه معاملات این هدیه</p>
              <div className="flex flex-col gap-1.5">
                {listing.transactions.map((t) => (
                  <div key={t.id} className="flex items-center justify-between text-[12px] text-muted-foreground">
                    <TxStatusBadge status={t.status} />
                    <span className="tnum">
                      {faDigits(t.amount)} {t.currency === "STARS" ? "⭐" : "TON"} — {timeAgoFa(t.createdAt)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Buy dialog */}
      <Dialog open={buyOpen} onOpenChange={setBuyOpen}>
        <DialogContent className="max-w-md border-border bg-card">
          {step === "pay" ? (
            <>
              <DialogHeader>
                <DialogTitle>خرید {listing.title}</DialogTitle>
                <DialogDescription>
                  پرداخت شفاف — مستقیم به فروشنده، بدون واسطهٔ مالی.
                </DialogDescription>
              </DialogHeader>

              <div className="flex flex-col gap-2 rounded-lg border border-border bg-background/50 p-3 text-[12px]">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">قیمت</span>
                  <span className="tnum font-semibold">
                    {faDigits(listing.price)} {listing.currency === "STARS" ? "⭐" : "TON"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">کارمزد فروش ({faDigits(feePercent)}٪)</span>
                  <span className="tnum text-petrol-bright">
                    {faDigits(feeAmount)} {listing.currency === "STARS" ? "⭐" : "TON"} → کیف پول کارمزد
                  </span>
                </div>
              </div>

              {listing.currency === "TON" ? (
                <div className="flex flex-col gap-3">
                  <Button onClick={payWithWallet} disabled={busy} className="w-full gap-2">
                    <Wallet className="size-4" />
                    پرداخت با کیف پول TON
                  </Button>
                  <div className="flex flex-col gap-2 rounded-lg border border-border p-3">
                    <p className="text-[12px] text-muted-foreground">یا انتقال دستی:</p>
                    <div className="flex items-center gap-1 text-[12px]">
                      <code className="flex-1 truncate rounded bg-secondary px-2 py-1.5 tnum" dir="ltr">
                        {listing.seller.tonWallet || "—"}
                      </code>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-8"
                        onClick={() => {
                          if (listing.seller.tonWallet) {
                            navigator.clipboard.writeText(listing.seller.tonWallet);
                            toast.success("آدرس کپی شد");
                          }
                        }}
                        aria-label="کپی آدرس"
                      >
                        <Copy className="size-3.5" />
                      </Button>
                    </div>
                    <Input
                      value={txHash}
                      onChange={(e) => setTxHash(e.target.value)}
                      placeholder="هش تراکنش (TxID) را اینجا بچسبانید"
                      className="h-9 text-left text-[12px]"
                      dir="ltr"
                    />
                    <Button
                      variant="secondary"
                      size="sm"
                      disabled={busy || txHash.trim().length < 8}
                      onClick={() => createTx("manual", txHash.trim())}
                    >
                      ثبت پرداخت دستی
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col gap-3">
                  <p className="text-[12px] leading-6 text-muted-foreground">
                    تسویهٔ استارز داخل تلگرام انجام می‌شود: مبلغ را با استارز پرداخت کنید و هدیه را از فروشنده دریافت
                    کنید؛ سپس فروشنده تأیید می‌زند و معامله نهایی می‌شود.
                  </p>
                  <Button onClick={() => createTx("stars_telegram")} disabled={busy}>
                    ثبت سفارش استارزی
                  </Button>
                </div>
              )}
            </>
          ) : (
            <>
              <DialogHeader>
                <DialogTitle>سفارش ثبت شد 🎉</DialogTitle>
                <DialogDescription>
                  پس از تأیید فروشنده، معامله نهایی و در فعالیت بازار ثبت می‌شود. می‌توانید وضعیت را در «حساب من» دنبال کنید.
                </DialogDescription>
              </DialogHeader>
              <div className="flex gap-2">
                <Button className="flex-1" onClick={() => { setBuyOpen(false); router.go("profile"); }}>
                  رفتن به حساب من
                </Button>
                <Button variant="outline" onClick={() => { setBuyOpen(false); load(); }}>
                  بستن
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
