"use client";

import { useEffect, useState } from "react";
import { useRouter } from "@/lib/nav";
import { useApp } from "@/lib/store";
import { Input } from "@/components/ui/input";
import GiftTable, { type ListingRow } from "@/components/giftify/GiftTable";
import ActivityTable, { type ActivityTx } from "@/components/giftify/ActivityTable";
import { EmptyState, SectionHeader, StatBox } from "@/components/giftify/bits";
import { faDigits } from "@/lib/format";
import { Search, PackageOpen, Activity as ActivityIcon } from "lucide-react";

type Stats = { active: number; sold: number; users: number; floorTon: number | null; volumeTon: number };
type Collection = { slug: string; name: string; emoji: string | null; activeCount: number };
type OfficialGift = { id: string; emoji: string | null; priceStars: number | null };

export default function HomeView() {
  const router = useRouter();
  const settings = useApp((s) => s.settings);
  const [stats, setStats] = useState<Stats | null>(null);
  const [listings, setListings] = useState<ListingRow[]>([]);
  const [activity, setActivity] = useState<ActivityTx[]>([]);
  const [collections, setCollections] = useState<Collection[]>([]);
  const [official, setOfficial] = useState<OfficialGift[]>([]);
  const [q, setQ] = useState("");

  useEffect(() => {
    fetch("/api/stats").then((r) => r.json()).then(setStats).catch(() => {});
    fetch("/api/listings?status=ACTIVE&limit=8").then((r) => r.json()).then((d) => setListings(d.listings || [])).catch(() => {});
    fetch("/api/activity").then((r) => r.json()).then((d) => setActivity(d.transactions || [])).catch(() => {});
    fetch("/api/collections").then((r) => r.json()).then((d) => setCollections(d.collections || [])).catch(() => {});
    fetch("/api/official-gifts").then((r) => r.json()).then((d) => setOfficial(d.gifts || [])).catch(() => {});
  }, []);

  const submitSearch = () => {
    router.go("market", q.trim() ? { q: q.trim() } : undefined);
  };

  const siteName = settings?.site_name || "گیفتیفای";

  return (
    <div>
      {/* Hero — minimal wordmark like Fragment */}
      <section className="hero-canvas border-b border-border/70">
        <div className="mx-auto flex max-w-3xl flex-col items-center gap-4 px-4 py-14 text-center md:py-20">
          <h1 className="font-nastaliq petrol-glow text-5xl text-foreground md:text-7xl">{siteName}</h1>
          <p className="text-[10px] font-semibold uppercase tracking-[0.55em] text-petrol-bright/70">GIFTIFY</p>
          <p className="max-w-xl text-sm leading-6 text-muted-foreground md:text-[15px]">
            {settings?.site_tagline || "بازار هدیه‌های تلگرام — بخر، بفروش، منتقل کن"}
          </p>
          <div className="relative mt-2 w-full max-w-xl">
            <Search className="absolute right-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && submitSearch()}
              placeholder="جست‌وجوی هدیه، مجموعه یا فروشنده…"
              className="h-12 rounded-full border-border bg-card pr-10 text-sm shadow-[0_0_40px_rgba(14,147,184,0.10)] focus-visible:ring-petrol"
              aria-label="جست‌وجو در بازار"
            />
          </div>
          <div className="mt-3 grid w-full max-w-xl grid-cols-2 gap-2.5 md:grid-cols-4">
            <StatBox label="آگهی فعال" value={faDigits(stats?.active ?? 0)} />
            <StatBox label="فروش موفق" value={faDigits(stats?.sold ?? 0)} />
            <StatBox label="کاربران" value={faDigits(stats?.users ?? 0)} />
            <StatBox
              label="کف قیمت TON"
              value={stats?.floorTon != null ? `${faDigits(stats.floorTon.toFixed(2))} TON` : "—"}
            />
          </div>
        </div>
      </section>

      <div className="mx-auto flex max-w-6xl flex-col gap-8 px-4 py-8">
        {/* Collections */}
        {collections.length > 0 && (
          <section className="flex flex-col gap-3">
            <SectionHeader title="مجموعه‌ها" action="بازار" onAction={() => router.go("market")} />
            <div className="flex flex-wrap gap-2">
              {collections.slice(0, 14).map((c) => (
                <button
                  key={c.slug}
                  onClick={() => router.go("market", { collection: c.slug })}
                  className="flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 text-xs text-foreground/85 transition hover:border-petrol/40 hover:text-petrol-bright"
                >
                  {c.emoji && <span>{c.emoji}</span>}
                  {c.name}
                  <span className="tnum text-[10px] text-muted-foreground">({faDigits(c.activeCount)})</span>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* Latest listings */}
        <section className="flex flex-col gap-3">
          <SectionHeader title="آخرین آگهی‌ها" action="همه" onAction={() => router.go("market")} />
          {listings.length > 0 ? (
            <GiftTable listings={listings} onOpen={(id) => router.go(`gift/${id}`)} />
          ) : (
            <EmptyState
              icon={<PackageOpen className="size-8 text-petrol-bright/60" />}
              title="هنوز آگهی‌ای ثبت نشده"
              hint="اولین نفری باشید که هدیهٔ تلگرامش را در گیفتیفای می‌فروشد. ثبت آگهی رایگان است و کارمزد فقط از روی فروش محاسبه می‌شود."
              cta="ثبت آگهی"
              onCta={() => router.go("sell")}
            />
          )}
        </section>

        {/* Activity */}
        <section className="flex flex-col gap-3">
          <SectionHeader title="آخرین فروش‌ها" />
          {activity.length > 0 ? (
            <ActivityTable transactions={activity} onOpen={(id) => router.go(`gift/${id}`)} />
          ) : (
            <EmptyState
              icon={<ActivityIcon className="size-8 text-petrol-bright/60" />}
              title="هنوز فروشی ثبت نشده"
              hint="به‌محض اولین معاملهٔ تأییدشده، آمار و فعالیت بازار همین‌جا نمایش داده می‌شود."
            />
          )}
        </section>

        {/* Official Telegram Stars gifts (synced via admin MTProto) */}
        {official.length > 0 && (
          <section className="flex flex-col gap-3">
            <SectionHeader title="هدیه‌های رسمی استارز تلگرام" action="بازار" onAction={() => router.go("market")} />
            <div className="grid grid-cols-3 gap-2.5 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8">
              {official.slice(0, 16).map((g) => (
                <div
                  key={g.id}
                  className="flex flex-col items-center gap-1 rounded-xl border border-border bg-card/60 p-3 text-center"
                >
                  <span className="text-2xl">{g.emoji || "🎁"}</span>
                  <span className="tnum text-[11px] font-semibold text-petrol-bright">
                    {g.priceStars != null ? `${faDigits(g.priceStars.toLocaleString("en-US"))} ⭐` : "—"}
                  </span>
                </div>
              ))}
            </div>
            <p className="text-[11px] text-muted-foreground">
              این فهرست از بازار رسمی تلگرام (api_id/api_hash شما) همگام‌سازی شده است.
            </p>
          </section>
        )}

        {/* How it works */}
        <section className="grid gap-2.5 rounded-xl border border-border bg-card/40 p-4 md:grid-cols-3">
          {[
            { t: "۱. ثبت آگهی", d: "هدیهٔ تلگرام خود را با قیمت TON یا استارز بفروشید." },
            { t: "۲. پرداخت مستقیم", d: `خریدار با کیف پول TON مستقیم به شما پرداخت می‌کند؛ کارمزد ${faDigits(settings?.fee_sale_percent ?? 5)}٪ فروش شفاف ثبت می‌شود.` },
            { t: "۳. تأیید و انتقال", d: "هدیه را داخل تلگرام منتقل کنید و فروش را تأیید بزنید." },
          ].map((s) => (
            <div key={s.t} className="rounded-lg border border-border/60 bg-background/40 p-3">
              <p className="mb-1 text-[13px] font-bold text-petrol-bright">{s.t}</p>
              <p className="text-[12px] leading-5 text-muted-foreground">{s.d}</p>
            </div>
          ))}
        </section>
      </div>
    </div>
  );
}
