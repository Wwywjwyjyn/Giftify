"use client";

import { useState } from "react";
import { useRouter } from "@/lib/nav";
import { useApp } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { LogIn, UserPlus, ShieldCheck } from "lucide-react";

export default function AuthView() {
  const router = useRouter();
  const refreshMe = useApp((s) => s.refreshMe);
  const [login, setLogin] = useState({ username: "", password: "" });
  const [reg, setReg] = useState({ username: "", password: "" });
  const [busy, setBusy] = useState(false);

  const submit = async (endpoint: "login" | "register", data: { username: string; password: string }) => {
    setBusy(true);
    try {
      const res = await fetch(`/api/auth/${endpoint}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "خطا");
      await refreshMe();
      if (d.firstUser) toast.success("شما اولین کاربر هستید — مدیر کل سایت شدید 👑");
      else toast.success("خوش آمدید!");
      router.go("");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "خطا");
    } finally {
      setBusy(false);
    }
  };

  const inputCls = "h-10 rounded-lg border-border bg-secondary text-[13px]";

  return (
    <div className="mx-auto max-w-md px-4 py-10">
      <div className="mb-6 text-center">
        <h1 className="font-nastaliq text-3xl text-foreground">گیفتیفای</h1>
        <p className="mt-1 text-[11px] text-muted-foreground">ورود یا ساخت حساب برای خرید و فروش</p>
      </div>

      <Tabs defaultValue="login" className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-secondary">
          <TabsTrigger value="login" className="text-xs">ورود</TabsTrigger>
          <TabsTrigger value="register" className="text-xs">ثبت‌نام</TabsTrigger>
        </TabsList>

        <TabsContent value="login">
          <form
            className="flex flex-col gap-3 rounded-2xl border border-border bg-card/50 p-5"
            onSubmit={(e) => {
              e.preventDefault();
              submit("login", login);
            }}
          >
            <div className="flex flex-col gap-1.5">
              <Label className="text-xs text-muted-foreground">نام کاربری</Label>
              <Input value={login.username} onChange={(e) => setLogin({ ...login, username: e.target.value })} className={inputCls} dir="ltr" />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label className="text-xs text-muted-foreground">رمز عبور</Label>
              <Input type="password" value={login.password} onChange={(e) => setLogin({ ...login, password: e.target.value })} className={inputCls} dir="ltr" />
            </div>
            <Button type="submit" disabled={busy} className="mt-1 gap-2">
              <LogIn className="size-4" />
              ورود
            </Button>
          </form>
        </TabsContent>

        <TabsContent value="register">
          <form
            className="flex flex-col gap-3 rounded-2xl border border-border bg-card/50 p-5"
            onSubmit={(e) => {
              e.preventDefault();
              submit("register", reg);
            }}
          >
            <div className="flex items-start gap-2 rounded-lg border border-petrol/25 bg-petrol-ink/40 p-2.5 text-[11px] leading-5 text-petrol-bright">
              <ShieldCheck className="mt-0.5 size-4 shrink-0" />
              نکتهٔ مهم: اولین حسابی که در سایت یا مینی‌اپ ساخته شود، به‌صورت خودکار «مدیر» می‌شود و به پنل مدیریت دسترسی
              کامل (کارمزدها، کیف پول کارمزد، کاربران و…) خواهد داشت.
            </div>
            <div className="flex flex-col gap-1.5">
              <Label className="text-xs text-muted-foreground">نام کاربری (انگلیسی)</Label>
              <Input
                value={reg.username}
                onChange={(e) => setReg({ ...reg, username: e.target.value })}
                className={inputCls}
                dir="ltr"
                placeholder="my_username"
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label className="text-xs text-muted-foreground">رمز عبور (حداقل ۶ کاراکتر)</Label>
              <Input
                type="password"
                value={reg.password}
                onChange={(e) => setReg({ ...reg, password: e.target.value })}
                className={inputCls}
                dir="ltr"
              />
            </div>
            <Button type="submit" disabled={busy} className="mt-1 gap-2">
              <UserPlus className="size-4" />
              ساخت حساب
            </Button>
          </form>
        </TabsContent>
      </Tabs>
    </div>
  );
}
