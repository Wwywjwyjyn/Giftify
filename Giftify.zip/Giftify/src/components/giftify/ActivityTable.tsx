"use client";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { PriceBadge } from "@/components/giftify/bits";
import { timeAgoFa } from "@/lib/format";

export type ActivityTx = {
  id: string;
  amount: number;
  currency: string;
  createdAt: string;
  listing: { id: string; title: string; emoji: string | null };
  buyer: { username: string } | null;
  seller: { username: string } | null;
};

/** Fragment-style recent-sales activity feed. */
export default function ActivityTable({
  transactions,
  onOpen,
}: {
  transactions: ActivityTx[];
  onOpen?: (listingId: string) => void;
}) {
  return (
    <div className="overflow-x-auto rounded-xl border border-border bg-card/50">
      <Table>
        <TableHeader>
          <TableRow className="hover:bg-transparent">
            <TableHead className="text-right text-[11px] font-semibold text-muted-foreground">هدیه</TableHead>
            <TableHead className="text-right text-[11px] font-semibold text-muted-foreground">فروشنده</TableHead>
            <TableHead className="text-right text-[11px] font-semibold text-muted-foreground">خریدار</TableHead>
            <TableHead className="hidden text-left text-[11px] font-semibold text-muted-foreground sm:table-cell">قیمت</TableHead>
            <TableHead className="text-left text-[11px] font-semibold text-muted-foreground">زمان</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {transactions.map((t) => (
            <TableRow
              key={t.id}
              onClick={() => onOpen?.(t.listing.id)}
              className={`row-hover border-border/60 ${onOpen ? "cursor-pointer" : ""}`}
            >
              <TableCell className="max-w-44 py-2.5">
                <div className="flex items-center gap-2">
                  <span className="text-base">{t.listing.emoji || "🎁"}</span>
                  <span className="truncate text-[12px] font-medium text-foreground/90">{t.listing.title}</span>
                </div>
              </TableCell>
              <TableCell className="text-[12px] text-muted-foreground">@{t.seller?.username || "—"}</TableCell>
              <TableCell className="text-[12px] text-muted-foreground">@{t.buyer?.username || "—"}</TableCell>
              <TableCell className="hidden text-left sm:table-cell">
                <PriceBadge amount={t.amount} currency={t.currency} size="sm" />
              </TableCell>
              <TableCell className="text-left text-[11px] text-muted-foreground">{timeAgoFa(t.createdAt)}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
