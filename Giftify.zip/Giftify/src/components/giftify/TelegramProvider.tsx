"use client";

import Script from "next/script";
import { useEffect } from "react";
import { useApp } from "@/lib/store";

/**
 * Telegram Mini App bootstrap: expands the webapp, applies safe areas,
 * and auto-logs the visitor in via signed initData.
 */
export default function TelegramProvider() {
  const refreshMe = useApp((s) => s.refreshMe);

  useEffect(() => {
    const tg = (window as unknown as { Telegram?: { WebApp?: Record<string, unknown> } }).Telegram?.WebApp;
    if (!tg) return;
    try {
      (tg.ready as () => void)();
      (tg.expand as () => void)();
      if (typeof tg.disableVerticalSwipes === "function") tg.disableVerticalSwipes();
      if (typeof tg.setHeaderColor === "function") tg.setHeaderColor("#06080a");
      if (typeof tg.setBackgroundColor === "function") tg.setBackgroundColor("#06080a");
    } catch {
      /* older clients */
    }

    const initData = tg.initData as string | undefined;
    if (initData) {
      fetch("/api/auth/telegram", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ initData }),
      })
        .then((r) => r.json())
        .then(() => refreshMe())
        .catch(() => {});
    }
  }, [refreshMe]);

  return (
    <Script src="https://telegram.org/js/telegram-web-app.js" strategy="afterInteractive" />
  );
}
