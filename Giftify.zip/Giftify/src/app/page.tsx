import GiftifyApp from "@/components/giftify/GiftifyApp";

export default function Page() {
  return <GiftifyApp />;
}
