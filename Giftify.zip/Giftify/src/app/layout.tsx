import type { Metadata, Viewport } from "next";
import localFont from "next/font/local";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";

const vazir = localFont({
  src: [
    { path: "../../public/fonts/Vazirmatn-Regular.woff2", weight: "400", style: "normal" },
    { path: "../../public/fonts/Vazirmatn-Medium.woff2", weight: "500", style: "normal" },
    { path: "../../public/fonts/Vazirmatn-SemiBold.woff2", weight: "600", style: "normal" },
    { path: "../../public/fonts/Vazirmatn-Bold.woff2", weight: "700", style: "normal" },
    { path: "../../public/fonts/Vazirmatn-Black.woff2", weight: "900", style: "normal" },
  ],
  variable: "--font-vazir",
  display: "swap",
});

const gulzar = localFont({
  src: [{ path: "../../public/fonts/Gulzar-Regular.ttf", weight: "400", style: "normal" }],
  variable: "--font-gulzar",
  display: "swap",
});

export const metadata: Metadata = {
  title: "گیفتیفای | Giftify — بازار هدیه‌های تلگرام",
  description:
    "گیفتیفای: بازار خرید و فروش هدیه‌های تلگرام — بخر، بفروش، با کیف پول TON و پرداخت شفاف.",
  icons: { icon: "/icon.svg" },
};

export const viewport: Viewport = {
  themeColor: "#06080a",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <body className={`${vazir.variable} ${gulzar.variable} antialiased bg-background text-foreground min-h-screen`}>
        {children}
        <Toaster theme="dark" position="top-center" richColors />
      </body>
    </html>
  );
}
