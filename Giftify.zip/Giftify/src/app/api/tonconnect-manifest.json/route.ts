import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

/**
 * Dynamic TonConnect manifest — works on any domain the app is deployed to,
 * including the Telegram Mini App host.
 */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const origin = process.env.NEXT_PUBLIC_SITE_URL || url.origin;
  return NextResponse.json(
    {
      url: origin,
      name: "Giftify",
      iconUrl: `${origin}/icon.svg`,
      termsOfUseUrl: `${origin}/`,
      privacyPolicyUrl: `${origin}/`,
    },
    { headers: { "Access-Control-Allow-Origin": "*" } }
  );
}
