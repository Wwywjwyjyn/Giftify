import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, unauthorized } from "@/lib/auth";
import { getSettings, num } from "@/lib/settings";

export const dynamic = "force-dynamic";

/**
 * Creates a purchase transaction. Payment itself is transparent and direct:
 *  - TON: buyer pays the seller's wallet (TonConnect or manual transfer).
 *  - STARS: settlement happens inside Telegram by transferring the gift.
 * The platform fee (set by the admin per-section) is recorded on the
 * transaction and earmarked for the admin's treasury wallet.
 */
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await getSessionUser();
  if (!user) return unauthorized();

  const listing = await db.listing.findUnique({ where: { id }, include: { seller: true } });
  if (!listing) return NextResponse.json({ error: "آگهی پیدا نشد." }, { status: 404 });
  if (listing.status !== "ACTIVE")
    return NextResponse.json({ error: "این آگهی قابل خرید نیست." }, { status: 400 });
  if (listing.sellerId === user.id)
    return NextResponse.json({ error: "نمی‌توانید آگهی خودتان را بخرید." }, { status: 400 });
  if (listing.currency === "TON" && !listing.seller.tonWallet)
    return NextResponse.json(
      { error: "فروشنده هنوز کیف پول TON ثبت نکرده — از او بخواهید در پروفایل کیف پولش را وارد کند." },
      { status: 400 }
    );

  const body = await req.json().catch(() => ({}));
  const method = ["ton_wallet", "manual", "stars_telegram"].includes(body.method)
    ? body.method
    : listing.currency === "STARS"
      ? "stars_telegram"
      : "manual";

  const settings = await getSettings();
  const feePercent = num(settings, "fee_sale_percent", 0);
  const feeAmount = Math.round(listing.price * feePercent) / 100;
  const feeWallet = settings.treasury_wallet || null;

  let tx;
  try {
    tx = await db.$transaction(async (txdb) => {
      const fresh = await txdb.listing.findUnique({ where: { id } });
      if (!fresh || fresh.status !== "ACTIVE") throw new Error("این آگهی همین حالا فروخته شد.");
      const created = await txdb.transaction.create({
        data: {
          listingId: listing.id,
          buyerId: user.id,
          sellerId: listing.sellerId,
          amount: listing.price,
          currency: listing.currency,
          feePercent,
          feeAmount,
          feeWallet,
          status: "PENDING",
          method,
          txHash: typeof body.txHash === "string" ? body.txHash.slice(0, 200) : null,
        },
      });
      await txdb.listing.update({
        where: { id: listing.id },
        data: { status: "PENDING_SOLD", buyerId: user.id },
      });
      return created;
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "خطا در ثبت سفارش.";
    return NextResponse.json({ error: msg }, { status: 400 });
  }

  return NextResponse.json({
    transaction: tx,
    breakdown: {
      price: listing.price,
      currency: listing.currency,
      feePercent,
      feeAmount,
      feeWallet,
      payableToSeller: listing.price,
    },
  });
}
