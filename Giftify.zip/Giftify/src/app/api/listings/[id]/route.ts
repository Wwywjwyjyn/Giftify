import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, unauthorized, forbidden } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const listing = await db.listing.findUnique({
    where: { id },
    include: {
      seller: { select: { id: true, username: true, tonWallet: true, telegramName: true } },
      buyer: { select: { id: true, username: true } },
      collection: { select: { name: true, slug: true, emoji: true } },
      transactions: {
        orderBy: { createdAt: "desc" },
        take: 5,
        select: { id: true, status: true, amount: true, currency: true, createdAt: true },
      },
    },
  });
  if (!listing) return NextResponse.json({ error: "آگهی پیدا نشد." }, { status: 404 });
  return NextResponse.json({ listing });
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await getSessionUser();
  if (!user) return unauthorized();
  const listing = await db.listing.findUnique({ where: { id } });
  if (!listing) return NextResponse.json({ error: "آگهی پیدا نشد." }, { status: 404 });
  if (listing.sellerId !== user.id && user.role !== "ADMIN") return forbidden();

  const body = await req.json().catch(() => ({}));
  const data: Record<string, unknown> = {};
  if (typeof body.title === "string" && body.title.trim().length >= 2) data.title = body.title.trim().slice(0, 80);
  if (typeof body.emoji === "string") data.emoji = body.emoji.trim().slice(0, 8) || null;
  if (typeof body.description === "string") data.description = body.description.trim().slice(0, 1000) || null;
  if (body.currency === "TON" || body.currency === "STARS") data.currency = body.currency;
  if (body.price !== undefined) {
    const p = parseFloat(body.price);
    if (!Number.isFinite(p) || p <= 0)
      return NextResponse.json({ error: "قیمت نامعتبر است." }, { status: 400 });
    data.price = p;
  }
  if (body.status === "WITHDRAWN") {
    if (listing.status === "SOLD" || listing.status === "PENDING_SOLD")
      return NextResponse.json({ error: "این آگهی در حال معامله است." }, { status: 400 });
    data.status = "WITHDRAWN";
  }
  if (body.status === "ACTIVE" && listing.status === "WITHDRAWN") data.status = "ACTIVE";

  const updated = await db.listing.update({
    where: { id },
    data,
    include: {
      seller: { select: { id: true, username: true, tonWallet: true } },
      collection: { select: { name: true, slug: true, emoji: true } },
    },
  });
  return NextResponse.json({ listing: updated });
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await getSessionUser();
  if (!user) return unauthorized();
  const listing = await db.listing.findUnique({ where: { id } });
  if (!listing) return NextResponse.json({ error: "آگهی پیدا نشد." }, { status: 404 });
  if (listing.sellerId !== user.id && user.role !== "ADMIN") return forbidden();
  if (listing.status === "PENDING_SOLD")
    return NextResponse.json({ error: "اول معاملهٔ در جریان را لغو کنید." }, { status: 400 });

  await db.transaction.deleteMany({ where: { listingId: id } });
  await db.listing.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
