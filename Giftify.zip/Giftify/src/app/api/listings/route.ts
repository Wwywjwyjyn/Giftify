import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, unauthorized } from "@/lib/auth";
import { getSettings, num } from "@/lib/settings";
import { slugify } from "@/lib/format";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const q = url.searchParams.get("q")?.trim() || "";
  const collection = url.searchParams.get("collection")?.trim() || "";
  const status = url.searchParams.get("status")?.trim() || "ACTIVE";
  const currency = url.searchParams.get("currency")?.trim() || "";
  const min = parseFloat(url.searchParams.get("min") || "");
  const max = parseFloat(url.searchParams.get("max") || "");
  const sort = url.searchParams.get("sort") || "newest";
  const limit = Math.min(parseInt(url.searchParams.get("limit") || "50"), 100);
  const mine = url.searchParams.get("mine") === "1";
  const sellerUsername = url.searchParams.get("seller")?.trim() || "";

  const where: Record<string, unknown> = {};
  if (status !== "all") where.status = status;
  if (currency === "TON" || currency === "STARS") where.currency = currency;
  if (Number.isFinite(min) || Number.isFinite(max)) {
    where.price = {
      ...(Number.isFinite(min) ? { gte: min } : {}),
      ...(Number.isFinite(max) ? { lte: max } : {}),
    };
  }
  if (q) {
    where.OR = [
      { title: { contains: q } },
      { collection: { is: { name: { contains: q } } } },
      { collection: { is: { slug: { contains: q } } } },
    ];
  }
  if (collection) {
    const col = await db.collection.findUnique({ where: { slug: collection } });
    where.collectionId = col?.id || "___none___";
  }
  if (mine) {
    const user = await getSessionUser();
    if (!user) return unauthorized();
    where.sellerId = user.id;
  } else if (sellerUsername) {
    const seller = await db.user.findUnique({ where: { username: sellerUsername } });
    where.sellerId = seller?.id || "___none___";
  }

  const orderBy: Record<string, "asc" | "desc"> =
    sort === "price_asc"
      ? { price: "asc" }
      : sort === "price_desc"
        ? { price: "desc" }
        : sort === "serial_asc"
          ? { serialNumber: "asc" }
          : { createdAt: "desc" };

  const listings = await db.listing.findMany({
    where,
    orderBy: [orderBy],
    take: limit,
    include: {
      seller: { select: { username: true } },
      collection: { select: { name: true, slug: true, emoji: true } },
    },
  });

  const total = await db.listing.count({ where });
  return NextResponse.json({ listings, total });
}

export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  const body = await req.json().catch(() => ({}));

  const title = String(body.title || "").trim();
  const currency = body.currency === "STARS" ? "STARS" : "TON";
  const price = parseFloat(body.price);
  const description = String(body.description || "").trim().slice(0, 1000);
  const emoji = String(body.emoji || "").trim().slice(0, 8) || null;
  const serialNumber = body.serialNumber ? parseInt(body.serialNumber) : null;

  if (title.length < 2 || title.length > 80)
    return NextResponse.json({ error: "نام هدیه باید بین ۲ تا ۸۰ کاراکتر باشد." }, { status: 400 });
  if (!Number.isFinite(price) || price <= 0)
    return NextResponse.json({ error: "قیمت را درست وارد کنید." }, { status: 400 });

  const settings = await getSettings();
  if (currency === "TON" && price < num(settings, "min_price_ton", 0.01))
    return NextResponse.json(
      { error: `حداقل قیمت ${num(settings, "min_price_ton", 0.01)} TON است.` },
      { status: 400 }
    );

  let collectionId: string | null = null;
  const colSlug = slugify(String(body.collectionName || body.collectionSlug || ""));
  if (colSlug) {
    const existing = await db.collection.findUnique({ where: { slug: colSlug } });
    if (existing) collectionId = existing.id;
    else {
      const created = await db.collection.create({
        data: {
          slug: colSlug,
          name: String(body.collectionName || body.collectionSlug).trim().slice(0, 40),
          emoji: emoji,
        },
      });
      collectionId = created.id;
    }
  }

  const listing = await db.listing.create({
    data: {
      title,
      emoji,
      collectionId,
      serialNumber: Number.isFinite(serialNumber as number) ? (serialNumber as number) : null,
      currency,
      price,
      description: description || null,
      sellerId: user.id,
    },
    include: {
      seller: { select: { username: true } },
      collection: { select: { name: true, slug: true, emoji: true } },
    },
  });
  return NextResponse.json({ listing });
}
