import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { createToken, authCookieOptions } from "@/lib/auth";
import { verifyInitData } from "@/lib/telegram-verify";

export const dynamic = "force-dynamic";

/**
 * Auto-login from the Telegram Mini App: validates initData using the bot token,
 * then creates/updates the user. The first account becomes admin.
 */
export async function POST(req: Request) {
  const { initData } = await req.json().catch(() => ({}));
  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  if (!botToken)
    return NextResponse.json(
      { error: "ورود با تلگرام فعال نیست — TELEGRAM_BOT_TOKEN در سرور تنظیم نشده است." },
      { status: 503 }
    );
  const result = verifyInitData(String(initData || ""), botToken);
  if (!result.ok || !result.user)
    return NextResponse.json({ error: "امضای تلگرام نامعتبر است." }, { status: 401 });

  const tg = result.user as { id: number; username?: string; first_name?: string; last_name?: string };
  const telegramId = String(tg.id);
  const name = [tg.first_name, tg.last_name].filter(Boolean).join(" ") || tg.username || telegramId;

  let user = await db.user.findUnique({ where: { telegramId } });
  if (!user) {
    const count = await db.user.count();
    let username = (tg.username || `tg_${telegramId}`).toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0, 20);
    if (username.length < 3) username = `tg_${telegramId}`;
    const clash = await db.user.findUnique({ where: { username } });
    if (clash) username = `${username.slice(0, 14)}_${telegramId.slice(-4)}`;
    user = await db.user.create({
      data: { username, telegramId, telegramName: name, role: count === 0 ? "ADMIN" : "USER" },
    });
  } else {
    await db.user.update({ where: { id: user.id }, data: { telegramName: name } });
  }

  const token = await createToken(user.id);
  const res = NextResponse.json({
    user: { id: user.id, username: user.username, role: user.role },
  });
  res.cookies.set(authCookieOptions(token));
  return res;
}
