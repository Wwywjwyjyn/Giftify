import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { createToken, authCookieOptions } from "@/lib/auth";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const { username, password } = await req.json().catch(() => ({}));
  if (!username || !password)
    return NextResponse.json({ error: "نام کاربری و رمز عبور لازم است." }, { status: 400 });
  if (!/^[a-zA-Z0-9_]{3,20}$/.test(username))
    return NextResponse.json(
      { error: "نام کاربری باید ۳ تا ۲۰ کاراکتر انگلیسی، عدد یا _ باشد." },
      { status: 400 }
    );
  if (String(password).length < 6)
    return NextResponse.json({ error: "رمز عبور حداقل ۶ کاراکتر باشد." }, { status: 400 });

  const existing = await db.user.findUnique({ where: { username } });
  if (existing)
    return NextResponse.json({ error: "این نام کاربری قبلاً گرفته شده است." }, { status: 409 });

  const count = await db.user.count();
  const settings = await getSettings();
  if (count > 0 && settings.allow_registration === "0")
    return NextResponse.json({ error: "ثبت‌نام فعلاً بسته است." }, { status: 403 });

  // The very first account that enters the site / mini-app becomes the owner (admin).
  const role = count === 0 ? "ADMIN" : "USER";
  const user = await db.user.create({
    data: { username, passwordHash: bcrypt.hashSync(String(password), 10), role },
  });

  const token = await createToken(user.id);
  const res = NextResponse.json({
    user: { id: user.id, username: user.username, role: user.role },
    firstUser: count === 0,
  });
  res.cookies.set(authCookieOptions(token));
  return res;
}
