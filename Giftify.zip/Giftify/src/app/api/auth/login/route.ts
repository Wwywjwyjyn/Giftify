import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { createToken, authCookieOptions } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const { username, password } = await req.json().catch(() => ({}));
  if (!username || !password)
    return NextResponse.json({ error: "نام کاربری و رمز عبور لازم است." }, { status: 400 });

  const user = await db.user.findUnique({ where: { username } });
  if (!user || !user.passwordHash || !bcrypt.compareSync(String(password), user.passwordHash))
    return NextResponse.json({ error: "نام کاربری یا رمز عبور اشتباه است." }, { status: 401 });

  const token = await createToken(user.id);
  const res = NextResponse.json({
    user: { id: user.id, username: user.username, role: user.role },
  });
  res.cookies.set(authCookieOptions(token));
  return res;
}
