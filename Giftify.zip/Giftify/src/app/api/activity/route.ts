import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

/** Recent confirmed sales — the Fragment-style activity feed. */
export async function GET() {
  const txs = await db.transaction.findMany({
    where: { status: "CONFIRMED" },
    orderBy: { confirmedAt: "desc" },
    take: 20,
    include: {
      listing: { select: { id: true, title: true, emoji: true } },
      buyer: { select: { username: true } },
      seller: { select: { username: true } },
    },
  });
  return NextResponse.json({ transactions: txs });
}
