import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, unauthorized, forbidden } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  if (user.role !== "ADMIN") return forbidden();

  const users = await db.user.findMany({
    orderBy: { createdAt: "asc" },
    select: {
      id: true,
      username: true,
      role: true,
      telegramId: true,
      telegramName: true,
      tonWallet: true,
      createdAt: true,
      _count: { select: { listings: true, purchases: true, sales: true } },
    },
  });
  return NextResponse.json({ users });
}

export async function PATCH(req: Request) {
  const admin = await getSessionUser();
  if (!admin) return unauthorized();
  if (admin.role !== "ADMIN") return forbidden();
  const { id, role } = await req.json().catch(() => ({}));
  if (!id || !["ADMIN", "USER"].includes(role))
    return NextResponse.json({ error: "پارامترها نامعتبر است." }, { status: 400 });
  if (id === admin.id)
    return NextResponse.json({ error: "نمی‌توانید نقش خودتان را تغییر دهید." }, { status: 400 });
  const updated = await db.user.update({ where: { id }, data: { role } });
  return NextResponse.json({ ok: true, role: updated.role });
}

export async function DELETE(req: Request) {
  const admin = await getSessionUser();
  if (!admin) return unauthorized();
  if (admin.role !== "ADMIN") return forbidden();
  const id = new URL(req.url).searchParams.get("id");
  if (!id) return NextResponse.json({ error: "شناسه کاربر لازم است." }, { status: 400 });
  if (id === admin.id)
    return NextResponse.json({ error: "نمی‌توانید خودتان را حذف کنید." }, { status: 400 });

  const listings = await db.listing.findMany({ where: { sellerId: id }, select: { id: true } });
  for (const l of listings) {
    await db.transaction.deleteMany({ where: { listingId: l.id } });
  }
  await db.listing.deleteMany({ where: { sellerId: id } });
  await db.user.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
