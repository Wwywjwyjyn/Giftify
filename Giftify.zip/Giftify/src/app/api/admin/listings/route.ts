import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, unauthorized, forbidden } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  if (user.role !== "ADMIN") return forbidden();
  const status = new URL(req.url).searchParams.get("status") || "";

  const listings = await db.listing.findMany({
    where: status && status !== "all" ? { status } : {},
    orderBy: { createdAt: "desc" },
    take: 200,
    include: {
      seller: { select: { username: true } },
      buyer: { select: { username: true } },
      collection: { select: { name: true, emoji: true } },
    },
  });
  return NextResponse.json({ listings });
}

export async function PATCH(req: Request) {
  const admin = await getSessionUser();
  if (!admin) return unauthorized();
  if (admin.role !== "ADMIN") return forbidden();
  const { id, status } = await req.json().catch(() => ({}));
  if (!id || !["ACTIVE", "WITHDRAWN"].includes(status))
    return NextResponse.json({ error: "پارامترها نامعتبر است." }, { status: 400 });
  const updated = await db.listing.update({ where: { id }, data: { status } });
  return NextResponse.json({ listing: updated });
}

export async function DELETE(req: Request) {
  const admin = await getSessionUser();
  if (!admin) return unauthorized();
  if (admin.role !== "ADMIN") return forbidden();
  const id = new URL(req.url).searchParams.get("id");
  if (!id) return NextResponse.json({ error: "شناسه آگهی لازم است." }, { status: 400 });
  await db.transaction.deleteMany({ where: { listingId: id } });
  await db.listing.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
