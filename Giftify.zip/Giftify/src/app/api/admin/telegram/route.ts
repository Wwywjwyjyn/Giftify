import { NextResponse } from "next/server";
import { getSessionUser, unauthorized, forbidden } from "@/lib/auth";
import {
  tgStatus,
  tgSaveConfig,
  tgSendCode,
  tgVerifyCode,
  tgSyncGifts,
  getTelegramConfig,
} from "@/lib/telegram";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function GET() {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  if (user.role !== "ADMIN") return forbidden();
  const status = await tgStatus();
  const lastSyncRow = await db.setting.findUnique({ where: { key: "tg_last_sync" } });
  return NextResponse.json({ ...status, lastSync: lastSyncRow?.value || null });
}

export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  if (user.role !== "ADMIN") return forbidden();

  const body = await req.json().catch(() => ({}));
  const action = body.action;

  try {
    if (action === "save") {
      const apiId = parseInt(body.apiId);
      const apiHash = String(body.apiHash || "").trim();
      const phone = String(body.phone || "").trim();
      if (!Number.isFinite(apiId) || apiId <= 0 || !apiHash || !phone)
        return NextResponse.json(
          { error: "api_id، api_hash و شماره تلفن همه لازم‌اند (از my.telegram.org)." },
          { status: 400 }
        );
      await tgSaveConfig(apiId, apiHash, phone);
      return NextResponse.json({ ok: true, message: "تنظیمات ذخیره شد — حالا کد تأیید را بگیرید." });
    }

    if (action === "send_code") {
      const cfg = await getTelegramConfig();
      if (!cfg.apiId || !cfg.apiHash || !cfg.phone)
        return NextResponse.json({ error: "اول api_id و api_hash و شماره را ذخیره کنید." }, { status: 400 });
      const r = await tgSendCode(cfg.apiId, cfg.apiHash, cfg.phone);
      return NextResponse.json({
        ok: true,
        message: r.viaApp
          ? "کد به تلگرام شما فرستاده شد."
          : "کد به شمارهٔ شما پیامک شد.",
      });
    }

    if (action === "verify") {
      const code = String(body.code || "").trim();
      if (!code) return NextResponse.json({ error: "کد تأیید را وارد کنید." }, { status: 400 });
      const r = await tgVerifyCode(code, body.password ? String(body.password) : undefined);
      if (r.needPassword)
        return NextResponse.json({ needPassword: true, message: "حساب شما رمز دو مرحله‌ای دارد — رمز را وارد کنید." });
      return NextResponse.json({ ok: true, message: "ورود موفق — سشن ذخیره شد." });
    }

    if (action === "sync") {
      const r = await tgSyncGifts();
      return NextResponse.json({ ok: true, message: `${r.synced} هدیهٔ رسمی همگام‌سازی شد.` });
    }

    if (action === "logout") {
      await db.setting.deleteMany({ where: { key: "tg_session" } });
      return NextResponse.json({ ok: true, message: "سشن تلگرام حذف شد." });
    }

    return NextResponse.json({ error: "عملیات ناشناخته." }, { status: 400 });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "خطای نامشخص تلگرام." },
      { status: 500 }
    );
  }
}
