import { NextResponse } from "next/server";
import { getSessionUser, unauthorized, forbidden } from "@/lib/auth";
import { getSettings, setSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

const ALLOWED_KEYS = new Set([
  "site_name",
  "site_tagline",
  "fee_sale_percent",
  "fee_transfer_percent",
  "fee_withdraw_percent",
  "treasury_wallet",
  "allow_registration",
  "min_price_ton",
]);

export async function GET() {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  if (user.role !== "ADMIN") return forbidden();
  const settings = await getSettings();
  return NextResponse.json({ settings });
}

export async function PUT(req: Request) {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  if (user.role !== "ADMIN") return forbidden();
  const body = await req.json().catch(() => ({}));

  const updates: Record<string, string> = {};
  for (const [k, v] of Object.entries(body)) {
    if (!ALLOWED_KEYS.has(k)) continue;
    const val = String(v ?? "").trim();
    if (k.startsWith("fee_") && k.endsWith("_percent")) {
      const n = parseFloat(val);
      if (!Number.isFinite(n) || n < 0 || n > 50)
        return NextResponse.json({ error: `مقدار کارمزد «${k}» باید بین ۰ تا ۵۰ درصد باشد.` }, { status: 400 });
    }
    if (k === "treasury_wallet" && val && val.length < 20)
      return NextResponse.json({ error: "آدرس کیف پول کارمزد معتبر نیست." }, { status: 400 });
    updates[k] = val;
  }
  await setSettings(updates);
  const settings = await getSettings();
  return NextResponse.json({ settings });
}
