import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, unauthorized, forbidden } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  if (user.role !== "ADMIN") return forbidden();

  const [users, listingsTotal, listingsActive, listingsSold, pendingTxs] = await Promise.all([
    db.user.count(),
    db.listing.count(),
    db.listing.count({ where: { status: "ACTIVE" } }),
    db.listing.count({ where: { status: "SOLD" } }),
    db.transaction.count({ where: { status: "PENDING" } }),
  ]);

  const confirmed = await db.transaction.findMany({ where: { status: "CONFIRMED" } });
  let volumeTon = 0;
  let volumeStars = 0;
  let feesTon = 0;
  let feesStars = 0;
  let feeWallet: string | null = null;
  for (const t of confirmed) {
    if (t.currency === "STARS") {
      volumeStars += t.amount;
      feesStars += t.feeAmount;
    } else {
      volumeTon += t.amount;
      feesTon += t.feeAmount;
    }
    feeWallet = t.feeWallet || feeWallet;
  }

  const recent = await db.transaction.findMany({
    orderBy: { createdAt: "desc" },
    take: 12,
    include: {
      listing: { select: { title: true, emoji: true } },
      buyer: { select: { username: true } },
      seller: { select: { username: true } },
    },
  });

  return NextResponse.json({
    users,
    listingsTotal,
    listingsActive,
    listingsSold,
    pendingTxs,
    volumeTon,
    volumeStars,
    feesTon,
    feesStars,
    feeWallet,
    recent,
  });
}
