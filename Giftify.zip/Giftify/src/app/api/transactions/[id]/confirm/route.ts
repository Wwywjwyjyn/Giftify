import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, unauthorized, forbidden } from "@/lib/auth";

export const dynamic = "force-dynamic";

/** Seller (or admin) confirms the deal after transferring the gift — fee becomes payable to the treasury wallet. */
export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await getSessionUser();
  if (!user) return unauthorized();

  const tx = await db.transaction.findUnique({ where: { id }, include: { listing: true } });
  if (!tx) return NextResponse.json({ error: "تراکنش پیدا نشد." }, { status: 404 });
  if (tx.sellerId !== user.id && user.role !== "ADMIN") return forbidden();
  if (tx.status !== "PENDING")
    return NextResponse.json({ error: "این تراکنش قابل تأیید نیست." }, { status: 400 });

  const updated = await db.$transaction([
    db.transaction.update({
      where: { id },
      data: { status: "CONFIRMED", confirmedAt: new Date() },
    }),
    db.listing.update({
      where: { id: tx.listingId },
      data: { status: "SOLD", buyerId: tx.buyerId, soldAt: new Date() },
    }),
  ]);
  return NextResponse.json({ transaction: updated[0] });
}
