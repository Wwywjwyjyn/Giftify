import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, unauthorized, forbidden } from "@/lib/auth";

export const dynamic = "force-dynamic";

/** Buyer, seller or admin can cancel a pending deal — the listing goes back on sale. */
export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await getSessionUser();
  if (!user) return unauthorized();

  const tx = await db.transaction.findUnique({ where: { id } });
  if (!tx) return NextResponse.json({ error: "تراکنش پیدا نشد." }, { status: 404 });
  if (tx.buyerId !== user.id && tx.sellerId !== user.id && user.role !== "ADMIN")
    return forbidden();
  if (tx.status !== "PENDING")
    return NextResponse.json({ error: "این تراکنش قابل لغو نیست." }, { status: 400 });

  const updated = await db.$transaction([
    db.transaction.update({ where: { id }, data: { status: "CANCELLED" } }),
    db.listing.update({
      where: { id: tx.listingId },
      data: { status: "ACTIVE", buyerId: null },
    }),
  ]);
  return NextResponse.json({ transaction: updated[0] });
}
