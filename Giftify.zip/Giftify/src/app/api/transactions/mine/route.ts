import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, unauthorized } from "@/lib/auth";

export const dynamic = "force-dynamic";

/** My transactions (as seller and as buyer). */
export async function GET() {
  const user = await getSessionUser();
  if (!user) return unauthorized();

  const include = {
    listing: { select: { id: true, title: true, emoji: true, currency: true, price: true } },
    buyer: { select: { id: true, username: true } },
    seller: { select: { id: true, username: true } },
  };

  const [asSeller, asBuyer] = await Promise.all([
    db.transaction.findMany({
      where: { sellerId: user.id },
      orderBy: { createdAt: "desc" },
      take: 50,
      include,
    }),
    db.transaction.findMany({
      where: { buyerId: user.id },
      orderBy: { createdAt: "desc" },
      take: 50,
      include,
    }),
  ]);
  return NextResponse.json({ asSeller, asBuyer });
}
