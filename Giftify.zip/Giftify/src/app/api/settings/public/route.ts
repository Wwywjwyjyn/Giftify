import { NextResponse } from "next/server";
import { getSettings, num } from "@/lib/settings";

export const dynamic = "force-dynamic";

/** Public settings: site identity + fee percentages (transparent for buyers/sellers). */
export async function GET() {
  const s = await getSettings();
  return NextResponse.json({
    site_name: s.site_name,
    site_tagline: s.site_tagline,
    fee_sale_percent: num(s, "fee_sale_percent", 5),
    fee_transfer_percent: num(s, "fee_transfer_percent", 2),
    fee_withdraw_percent: num(s, "fee_withdraw_percent", 1),
    treasury_wallet_set: Boolean(s.treasury_wallet),
    allow_registration: s.allow_registration !== "0",
  });
}
