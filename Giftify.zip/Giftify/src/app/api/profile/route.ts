import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, unauthorized } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function PATCH(req: Request) {
  const user = await getSessionUser();
  if (!user) return unauthorized();
  const body = await req.json().catch(() => ({}));
  const data: { tonWallet?: string | null } = {};
  if (typeof body.tonWallet === "string") {
    const w = body.tonWallet.trim();
    if (w && !/^[EU]Q[A-Za-z0-9_-]{43,60}$/.test(w) && !/^0:[0-9a-fA-F]{64}$/.test(w))
      return NextResponse.json({ error: "آدرس TON معتبر به نظر نمی‌رسد." }, { status: 400 });
    data.tonWallet = w || null;
  }
  const updated = await db.user.update({ where: { id: user.id }, data });
  return NextResponse.json({ ok: true, tonWallet: updated.tonWallet });
}
