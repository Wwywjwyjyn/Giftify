import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

/** Public marketplace stats for the homepage. */
export async function GET() {
  const [active, sold, users, collections] = await Promise.all([
    db.listing.count({ where: { status: "ACTIVE" } }),
    db.listing.count({ where: { status: "SOLD" } }),
    db.user.count(),
    db.collection.count(),
  ]);
  const [aggVolume, aggStars, minPriceRow] = await Promise.all([
    db.transaction.aggregate({ where: { status: "CONFIRMED", currency: "TON" }, _sum: { amount: true } }),
    db.transaction.aggregate({ where: { status: "CONFIRMED", currency: "STARS" }, _sum: { amount: true } }),
    db.listing.findMany({ where: { status: "ACTIVE", currency: "TON" }, orderBy: { price: "asc" }, take: 1, select: { price: true } }),
  ]);
  return NextResponse.json({
    active,
    sold,
    users,
    collections,
    volumeTon: aggVolume._sum.amount || 0,
    volumeStars: aggStars._sum.amount || 0,
    floorTon: minPriceRow[0]?.price ?? null,
  });
}
