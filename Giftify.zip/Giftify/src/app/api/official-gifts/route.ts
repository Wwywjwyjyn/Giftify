import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

/** Official Telegram Stars gifts, synced by the admin via MTProto (api_id/api_hash). */
export async function GET() {
  const gifts = await db.officialGift.findMany({
    orderBy: { priceStars: "asc" },
    take: 80,
  });
  const settings = await getSettings();
  return NextResponse.json({
    gifts,
    lastSync: settings.tg_last_sync || null,
  });
}
