const FA_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

export function faDigits(input: string | number): string {
  return String(input).replace(/[0-9]/g, (d) => FA_DIGITS[Number(d)]);
}

export function formatAmount(n: number, currency: string): string {
  if (currency === "STARS") {
    return `${faDigits(Math.round(n).toLocaleString("en-US"))} ⭐`;
  }
  // TON — up to 2 decimals, trimmed
  const v = Number.isInteger(n) ? n.toString() : n.toFixed(2).replace(/\.?0+$/, "");
  return `${faDigits(v)} TON`;
}

export function timeAgoFa(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  const sec = Math.max(1, Math.floor((Date.now() - d.getTime()) / 1000));
  if (sec < 60) return "لحظه‌ای پیش";
  const min = Math.floor(sec / 60);
  if (min < 60) return `${faDigits(min)} دقیقه پیش`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${faDigits(hr)} ساعت پیش`;
  const day = Math.floor(hr / 24);
  if (day < 30) return `${faDigits(day)} روز پیش`;
  const month = Math.floor(day / 30);
  if (month < 12) return `${faDigits(month)} ماه پیش`;
  return `${faDigits(Math.floor(month / 12))} سال پیش`;
}

export function slugify(text: string): string {
  return text
    .trim()
    .toLowerCase()
    .replace(/[\s_]+/g, "-")
    .replace(/[^a-z0-9\u0600-\u06FF-]/g, "")
    .replace(/-+/g, "-")
    .slice(0, 40);
}
