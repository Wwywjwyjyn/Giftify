import { db } from "@/lib/db";

/**
 * Central site settings, managed from the admin panel.
 * Fees are per-section percentages; the fee destination wallet is set by the admin.
 */
export const SETTINGS_DEFAULTS: Record<string, string> = {
  site_name: "گیفتیفای",
  site_tagline: "بازار هدیه‌های تلگرام — بخر، بفروش، منتقل کن",
  fee_sale_percent: "5",
  fee_transfer_percent: "2",
  fee_withdraw_percent: "1",
  treasury_wallet: "",
  allow_registration: "1",
  min_price_ton: "0.01",
};

export type SiteSettings = Record<string, string>;

export async function getSettings(): Promise<SiteSettings> {
  const rows = await db.setting.findMany();
  const s: SiteSettings = { ...SETTINGS_DEFAULTS };
  for (const r of rows) s[r.key] = r.value;
  return s;
}

export async function setSettings(entries: Record<string, string>): Promise<void> {
  const ops = Object.entries(entries).map(([key, value]) =>
    db.setting.upsert({ where: { key }, update: { value }, create: { key, value } })
  );
  await db.$transaction(ops);
}

export function num(s: SiteSettings | undefined, key: string, fallback = 0): number {
  if (!s) return fallback;
  const v = parseFloat(s[key]);
  return Number.isFinite(v) ? v : fallback;
}
