import crypto from "crypto";

/**
 * Verifies Telegram Mini App initData (HMAC-SHA256 per official spec).
 * https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
 */
export function verifyInitData(
  initData: string,
  botToken: string,
  maxAgeSeconds = 60 * 60 * 24
): { ok: boolean; user?: Record<string, unknown>; startParam?: string; error?: string } {
  if (!initData || !botToken) return { ok: false, error: "initData or bot token missing" };

  const params = new URLSearchParams(initData);
  const hash = params.get("hash");
  if (!hash) return { ok: false, error: "hash missing" };
  params.delete("hash");

  const dataCheckString = [...params.entries()]
    .map(([k, v]) => `${k}=${v}`)
    .sort()
    .join("\n");

  const secretKey = crypto.createHmac("sha256", "WebAppData").update(botToken).digest();
  const computed = crypto.createHmac("sha256", secretKey).update(dataCheckString).digest("hex");

  const a = Buffer.from(computed, "hex");
  const b = Buffer.from(hash, "hex");
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return { ok: false, error: "signature mismatch" };
  }

  const authDate = Number(params.get("auth_date"));
  if (!authDate || Date.now() / 1000 - authDate > maxAgeSeconds) {
    return { ok: false, error: "data expired" };
  }

  let user: Record<string, unknown> | undefined;
  try {
    user = JSON.parse(params.get("user") || "null") || undefined;
  } catch {
    user = undefined;
  }
  return { ok: true, user, startParam: params.get("start_param") || undefined };
}
