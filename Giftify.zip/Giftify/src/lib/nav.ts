"use client";

import { useApp, type Route } from "@/lib/store";
import { useEffect } from "react";

/**
 * Tiny hash-based router.
 * The whole Giftify app is a single-page application (`/`), which keeps it
 * compatible with the Telegram Mini App and any static/proxy deployment.
 * Views are addressed as `#/market`, `#/gift/<id>`, `#/admin`, …
 */
export function useRouter() {
  const go = useApp((s) => s.go);
  return { go };
}

export function navigate(path: string, params?: Record<string, string>) {
  const qs = params && Object.keys(params).length ? new URLSearchParams(params).toString() : "";
  window.location.hash = `#/${path}${qs ? `?${qs}` : ""}`;
}

export function routeEquals(a: Route, path: string) {
  return a.path === path;
}
