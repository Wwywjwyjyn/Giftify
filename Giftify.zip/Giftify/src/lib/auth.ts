import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import { db } from "@/lib/db";

const secretString =
  process.env.JWT_SECRET || process.env.APP_SECRET || "giftify-dev-secret-change-me";
const SECRET = new TextEncoder().encode(secretString);

export const COOKIE_NAME = "giftify_session";
const MAX_AGE = 60 * 60 * 24 * 30; // 30 days

export type SessionUser = {
  id: string;
  username: string;
  role: string;
  telegramId: string | null;
  telegramName: string | null;
  tonWallet: string | null;
  createdAt: Date;
};

export async function createToken(userId: string): Promise<string> {
  return new SignJWT({ uid: userId })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("30d")
    .sign(SECRET);
}

export const authCookieOptions = (token: string) => ({
  name: COOKIE_NAME,
  value: token,
  httpOnly: true,
  sameSite: "lax" as const,
  secure: process.env.NODE_ENV === "production",
  path: "/",
  maxAge: MAX_AGE,
});

export async function getSessionUser(): Promise<SessionUser | null> {
  try {
    const store = await cookies();
    const token = store.get(COOKIE_NAME)?.value;
    if (!token) return null;
    const { payload } = await jwtVerify(token, SECRET);
    const uid = payload.uid as string | undefined;
    if (!uid) return null;
    const user = await db.user.findUnique({ where: { id: uid } });
    if (!user) return null;
    return {
      id: user.id,
      username: user.username,
      role: user.role,
      telegramId: user.telegramId,
      telegramName: user.telegramName,
      tonWallet: user.tonWallet,
      createdAt: user.createdAt,
    };
  } catch {
    return null;
  }
}

export function unauthorized(msg = "برای این کار باید وارد حساب شوید.") {
  return Response.json({ error: msg }, { status: 401 });
}

export function forbidden(msg = "دسترسی فقط برای مدیر سایت مجاز است.") {
  return Response.json({ error: msg }, { status: 403 });
}
