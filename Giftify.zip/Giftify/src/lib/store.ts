"use client";

import { create } from "zustand";
import { useEffect } from "react";

export type Route = { path: string; params: URLSearchParams };

export type AppUser = {
  id: string;
  username: string;
  role: string;
  telegramId: string | null;
  telegramName: string | null;
  tonWallet: string | null;
};

export type AppSettings = {
  site_name: string;
  site_tagline: string;
  fee_sale_percent: number;
  fee_transfer_percent: number;
  fee_withdraw_percent: number;
  treasury_wallet_set: boolean;
  allow_registration: boolean;
};

type AppState = {
  route: Route;
  user: AppUser | null;
  settings: AppSettings | null;
  authChecked: boolean;
  go: (path: string, params?: Record<string, string>) => void;
  setRoute: (r: Route) => void;
  refreshMe: () => Promise<void>;
};

function parseHash(): Route {
  const raw = window.location.hash.replace(/^#\/?/, "");
  const [path, qs] = raw.split("?");
  return { path: path || "", params: new URLSearchParams(qs || "") };
}

export const useApp = create<AppState>((set) => ({
  route: { path: "", params: new URLSearchParams() },
  user: null,
  settings: null,
  authChecked: false,
  go: (path, params) => {
    const qs = params && Object.keys(params).length ? new URLSearchParams(params).toString() : "";
    window.location.hash = `#/${path}${qs ? `?${qs}` : ""}`;
  },
  setRoute: (r) => set({ route: r }),
  refreshMe: async () => {
    try {
      const [me, pub] = await Promise.all([
        fetch("/api/auth/me").then((r) => r.json()),
        fetch("/api/settings/public").then((r) => r.json()),
      ]);
      set({ user: me.user || null, settings: pub, authChecked: true });
    } catch {
      set({ authChecked: true });
    }
  },
}));

/** Keeps the zustand route in sync with the URL hash (SPA routing that also works inside the Telegram Mini App). */
export function useHashRouter() {
  const setRoute = useApp((s) => s.setRoute);
  useEffect(() => {
    const apply = () => setRoute(parseHash());
    apply();
    window.addEventListener("hashchange", apply);
    return () => window.removeEventListener("hashchange", apply);
  }, [setRoute]);
}
