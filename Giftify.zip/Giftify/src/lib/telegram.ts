import crypto from "crypto";
import { db } from "@/lib/db";

/**
 * Telegram MTProto (GramJS) integration — used by the admin panel to pull the
 * official Telegram Stars gifts catalog (api_id / api_hash from my.telegram.org).
 * The MTProto session is stored encrypted in the Settings table.
 */
export type TgConfig = {
  apiId: number;
  apiHash: string;
  phone: string;
  sessionEnc: string;
};

function secretKey(): Buffer {
  const s = process.env.APP_SECRET || process.env.JWT_SECRET || "giftify-dev-secret-change-me";
  return crypto.createHash("sha256").update(s).digest();
}

export function encrypt(text: string): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", secretKey(), iv);
  const enc = Buffer.concat([cipher.update(text, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([iv, tag, enc]).toString("base64");
}

export function decrypt(payload: string): string {
  const buf = Buffer.from(payload, "base64");
  const iv = buf.subarray(0, 12);
  const tag = buf.subarray(12, 28);
  const data = buf.subarray(28);
  const decipher = crypto.createDecipheriv("aes-256-gcm", secretKey(), iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(data), decipher.final()]).toString("utf8");
}

export async function getTelegramConfig(): Promise<TgConfig> {
  const rows = await db.setting.findMany({
    where: { key: { in: ["tg_api_id", "tg_api_hash", "tg_phone", "tg_session"] } },
  });
  const map = Object.fromEntries(rows.map((r) => [r.key, r.value]));
  return {
    apiId: Number(map.tg_api_id || 0),
    apiHash: map.tg_api_hash || "",
    phone: map.tg_phone || "",
    sessionEnc: map.tg_session || "",
  };
}

// In-memory auth state (dev-server friendly). After verify, the session string is persisted.
let authClient: unknown = null;
let authPhone = "";
let authPhoneCodeHash = "";

async function makeClient(apiId: number, apiHash: string, session: string): Promise<unknown> {
  const { TelegramClient } = await import("telegram");
  const { StringSession } = await import("telegram/sessions");
  const client = new TelegramClient(new StringSession(session), apiId, apiHash, {
    connectionRetries: 3,
    requestRetries: 2,
  });
  await (client as any).connect();
  return client;
}

async function getClient(): Promise<unknown | null> {
  const cfg = await getTelegramConfig();
  if (!cfg.apiId || !cfg.apiHash) throw new Error("ابتدا api_id و api_hash را در پنل ذخیره کنید.");
  if (!cfg.sessionEnc) return null;
  return makeClient(cfg.apiId, cfg.apiHash, decrypt(cfg.sessionEnc));
}

export async function tgSaveConfig(apiId: number, apiHash: string, phone: string) {
  const ops = [
    db.setting.upsert({
      where: { key: "tg_api_id" },
      update: { value: String(apiId) },
      create: { key: "tg_api_id", value: String(apiId) },
    }),
    db.setting.upsert({
      where: { key: "tg_api_hash" },
      update: { value: apiHash },
      create: { key: "tg_api_hash", value: apiHash },
    }),
    db.setting.upsert({
      where: { key: "tg_phone" },
      update: { value: phone },
      create: { key: "tg_phone", value: phone },
    }),
  ];
  await db.$transaction(ops);
}

export async function tgSendCode(apiId: number, apiHash: string, phone: string) {
  authClient = await makeClient(apiId, apiHash, "");
  authPhone = phone;
  const res = await (authClient as any).sendCode({ apiId, apiHash }, phone);
  authPhoneCodeHash = res.phoneCodeHash;
  return { sent: true, viaApp: Boolean(res.isCodeViaApp) };
}

export async function tgVerifyCode(code: string, password?: string) {
  if (!authClient) throw new Error("اول کد تأیید را بگیرید (مرحلهٔ قبل).");
  const { Api } = await import("telegram");
  const client = authClient as any;
  try {
    await client.invoke(
      new Api.auth.SignIn({
        phoneNumber: authPhone,
        phoneCodeHash: authPhoneCodeHash,
        phoneCode: code,
      })
    );
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : String(e);
    if (msg.includes("SESSION_PASSWORD_NEEDED") || msg.includes("SESSION_PASSWORD")) {
      if (!password) return { needPassword: true };
      try {
        await client.signInWithPassword(
          { apiId: (await getTelegramConfig()).apiId, apiHash: (await getTelegramConfig()).apiHash },
          { password, onError: () => {} }
        );
      } catch (e2: unknown) {
        throw new Error("رمز دو مرحله‌ای نامعتبر است: " + (e2 instanceof Error ? e2.message : String(e2)));
      }
    } else {
      throw new Error("ورود ناموفق بود: " + msg);
    }
  }
  const session = client.session.save();
  await db.setting.upsert({
    where: { key: "tg_session" },
    update: { value: encrypt(String(session)) },
    create: { key: "tg_session", value: encrypt(String(session)) },
  });
  authClient = null;
  authPhoneCodeHash = "";
  return { loggedIn: true };
}

export async function tgStatus() {
  const cfg = await getTelegramConfig();
  return {
    configured: Boolean(cfg.apiId && cfg.apiHash),
    authorized: Boolean(cfg.sessionEnc),
    phone: cfg.phone ? cfg.phone.replace(/(\d{4})\d+(\d{2})/, "$1****$2") : "",
  };
}

export async function tgSyncGifts(): Promise<{ synced: number; error?: string }> {
  const client = await getClient();
  if (!client) throw new Error("سشن تلگرام ساخته نشده — ابتدا وارد شوید.");
  const { Api } = await import("telegram");
  const res: any = await (client as any).invoke(new Api.payments.GetStarGifts({ hash: BigInt(0) }));
  const gifts = res?.gifts || [];
  let synced = 0;
  for (const g of gifts) {
    if (!g?.id) continue;
    const id = String(g.id);
    let emoji: string | null = null;
    try {
      const attrs = g.sticker?.attributes || [];
      const custom = attrs.find((a: unknown) => a?.className === "DocumentAttributeCustomEmoji");
      if (custom?.alt) emoji = custom.alt;
    } catch {
      emoji = null;
    }
    const data = {
      name: `هدیهٔ رسمی #${id}`,
      emoji,
      priceStars: g.stars != null ? Number(g.stars) : null,
      convertStars: g.convertStars != null ? Number(g.convertStars) : null,
      limited: Boolean(g.limited),
      firstSaleDate: g.firstSaleDate != null ? Number(g.firstSaleDate) : null,
    };
    await db.officialGift.upsert({ where: { id }, update: data, create: { id, ...data } });
    synced++;
  }
  await db.setting.upsert({
    where: { key: "tg_last_sync" },
    update: { value: new Date().toISOString() },
    create: { key: "tg_last_sync", value: new Date().toISOString() },
  });
  return { synced };
}
